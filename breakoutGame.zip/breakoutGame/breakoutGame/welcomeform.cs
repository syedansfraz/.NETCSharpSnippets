﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace breakoutGame
{
    public partial class welcomeform : Form
    {
        public welcomeform()
        {
            InitializeComponent();
            welcomepanel.Visible = true;
        }

        private void startnowbtn_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                this.Hide();
                welcomepanel.Hide();
                Form1 form1 = new Form1();
                form1.valueSet(4, 4, 11);
                form1.ShowDialog();
            }
            else if (radioButton2.Checked)
            {
                this.Hide();
                welcomepanel.Hide();
                Form1 form1 = new Form1();
                form1.valueSet(7, 7, 11);
                form1.ShowDialog();

                // hardness(6, 6, 11);
            }
            else if (radioButton3.Checked)
            {
                this.Hide();
                Form1 form1 = new Form1();
                form1.valueSet(10, 10, 10);
                form1.ShowDialog();

                // hardness(8, 8, 11);
            }
            else
            {
                MessageBox.Show("Please select one of them", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void welcomeform_Load(object sender, EventArgs e)
        {

        }
    }
}
