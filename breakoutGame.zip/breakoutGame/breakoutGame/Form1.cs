namespace breakoutGame
{
    public partial class Form1 : Form
    {
        bool goLeft;
        bool goRight;
        bool isGameover;

        int score;
        int ballx=0;
        int bally=0;
        int playerSpeed;
        Random random = new Random();
        public Form1()
        {

            InitializeComponent();

            resultPanel.Visible = false;
            //welcomepanel.Visible = true;
            // welcomepanel.Show();


        }
        public void valueSet(int x, int y, int speed)
            {
                ballx = x;  
            bally = y;
            playerSpeed = speed;
            game();
            }
        /*  public void hardness(int x, int y, int playersp)
          {
              this.ballx = x;
              this.bally = y;
              this.playerSpeed = playersp;
              welcomepanel.Visible = false;
          }*/
        //game();
        public void game()
        {

           // ballx = 5;
            //bally = 5;
            //playerSpeed = 12;
            score = 0;
            scorelabel.Text = "Score: " + score;
            timerforgame.Start();
            foreach (Control x in this.Controls)
            {
                if (x is Label && (string)x.Tag == "blocks")
                {

                    x.BackColor = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
                }
            }

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timerEvent(object sender, EventArgs e)
        {
            if (goLeft == true && player.Left > 0)
            {
                player.Left -= playerSpeed;
            }
            if (goRight == true && player.Right < 876)
            {
                player.Left += playerSpeed;
            }
            ball.Left += ballx;
            ball.Top += bally;
            if (ball.Left < 0 || ball.Left > 844)
            {
                ballx = -ballx;
            }
            if (ball.Top < 0)
            {
                bally = -bally;
            }
            if (ball.Bounds.IntersectsWith(player.Bounds))
            {
                // if (bally == 5)
                //{
                bally = random.Next(bally, 11) * -1;
                if (ballx < 0)
                {
                    ballx = random.Next(ballx, 11) * -1;
                }
                else
                {
                    ballx = random.Next(ballx, 11);
                }
                /* }
                 if (bally == 6)
                 {
                     bally = random.Next(6, 11) * -1;
                     if (ballx < 0)
                     {
                         ballx = random.Next(6, 11) * -1;
                     }
                     else
                     {
                         ballx = random.Next(6, 11);
                     }
                 }
                 if (bally == 8)
                 {
                     bally = random.Next(8, 11) * -1;
                     if (ballx < 0)
                     {
                         ballx = random.Next(8, 11) * -1;
                     }
                     else
                     {
                         ballx = random.Next(8, 11);
                     }
                 }
                */
            }
            foreach (Control x in this.Controls)
            {
                if (x is Label && (string)x.Tag == "blocks")
                {
                    if (ball.Bounds.IntersectsWith(x.Bounds))
                    {
                        score += 1;
                        //bally = 1;

                        scorelabel.Text = "Score: " + score;
                        bally = -bally;
                        this.Controls.Remove(x);

                    }
                }
            }
            if (score == 30)
            {
                resultPanel.Visible = true;
                labelofresult.Text = "Congratulations, You Won!!";
                labelscore.Text = "" + score;
                gameOver();

            }
            if (ball.Top > 579)
            {
                resultPanel.Visible = true;
                labelofresult.Text = "Hard Luck, You Lose!!";
                labelscore.Text = "" + score;
                gameOver();
            }
        }
        private void gameOver()
        {
            isGameover = true;
            timerforgame.Stop();
        }
        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void keyisUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goLeft = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                goRight = false;
            }
            if (e.KeyCode == Keys.Enter && isGameover == true)
            {
                this.Hide();
                welcomeform form1 = new welcomeform();
                form1.ShowDialog();
                resultPanel.Visible = false;
            }
            if (e.KeyCode == Keys.Escape)
            {
                Environment.Exit(0);
            }
        }
        private void keyisDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Left)
            {
                goLeft = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                goRight = true;
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void resultPanel_Paint(object sender, PaintEventArgs e)
        {

        }
        public void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

    }
}