﻿namespace breakoutGame
{
    partial class welcomeform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(welcomeform));
            welcomepanel = new Panel();
            startnowbtn = new Button();
            radioButton3 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            pictureBox1 = new PictureBox();
            label34 = new Label();
            label2 = new Label();
            welcomepanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // welcomepanel
            // 
            welcomepanel.Controls.Add(startnowbtn);
            welcomepanel.Controls.Add(radioButton3);
            welcomepanel.Controls.Add(radioButton2);
            welcomepanel.Controls.Add(radioButton1);
            welcomepanel.Controls.Add(pictureBox1);
            welcomepanel.Controls.Add(label34);
            welcomepanel.Controls.Add(label2);
            welcomepanel.Location = new Point(0, 0);
            welcomepanel.Name = "welcomepanel";
            welcomepanel.Size = new Size(884, 633);
            welcomepanel.TabIndex = 8;
            // 
            // startnowbtn
            // 
            startnowbtn.BackColor = Color.MintCream;
            startnowbtn.ForeColor = Color.White;
            startnowbtn.Image = (Image)resources.GetObject("startnowbtn.Image");
            startnowbtn.Location = new Point(410, 473);
            startnowbtn.Name = "startnowbtn";
            startnowbtn.Size = new Size(77, 70);
            startnowbtn.TabIndex = 36;
            startnowbtn.UseVisualStyleBackColor = false;
            startnowbtn.Click += startnowbtn_Click;
            // 
            // radioButton3
            // 
            radioButton3.Font = new Font("Segoe UI", 13F, FontStyle.Bold, GraphicsUnit.Point);
            radioButton3.ForeColor = Color.Teal;
            radioButton3.Image = (Image)resources.GetObject("radioButton3.Image");
            radioButton3.ImageAlign = ContentAlignment.MiddleLeft;
            radioButton3.Location = new Point(234, 428);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(176, 40);
            radioButton3.TabIndex = 6;
            radioButton3.TabStop = true;
            radioButton3.Text = "Difficult";
            radioButton3.TextAlign = ContentAlignment.MiddleRight;
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.Font = new Font("Segoe UI", 13F, FontStyle.Bold, GraphicsUnit.Point);
            radioButton2.ForeColor = Color.Teal;
            radioButton2.Image = (Image)resources.GetObject("radioButton2.Image");
            radioButton2.ImageAlign = ContentAlignment.MiddleLeft;
            radioButton2.Location = new Point(234, 377);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(176, 40);
            radioButton2.TabIndex = 5;
            radioButton2.TabStop = true;
            radioButton2.Text = "Medium";
            radioButton2.TextAlign = ContentAlignment.MiddleRight;
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.Font = new Font("Segoe UI", 13F, FontStyle.Bold, GraphicsUnit.Point);
            radioButton1.ForeColor = Color.Teal;
            radioButton1.Image = (Image)resources.GetObject("radioButton1.Image");
            radioButton1.ImageAlign = ContentAlignment.MiddleLeft;
            radioButton1.Location = new Point(234, 323);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(129, 43);
            radioButton1.TabIndex = 4;
            radioButton1.TabStop = true;
            radioButton1.Text = "Easy";
            radioButton1.TextAlign = ContentAlignment.MiddleRight;
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(584, 27);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(109, 107);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // label34
            // 
            label34.BackColor = Color.Teal;
            label34.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label34.ForeColor = Color.White;
            label34.Location = new Point(110, 223);
            label34.Name = "label34";
            label34.Size = new Size(300, 60);
            label34.TabIndex = 1;
            label34.Text = "Please Select Level of Hardness";
            label34.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.BackColor = Color.Teal;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(234, 27);
            label2.Name = "label2";
            label2.Size = new Size(341, 107);
            label2.TabIndex = 0;
            label2.Text = "Welcome to Breakout Game!";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // welcomeform
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(885, 632);
            Controls.Add(welcomepanel);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "welcomeform";
            Text = "Breakout Game";
            Load += welcomeform_Load;
            welcomepanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel welcomepanel;
        private Button startnowbtn;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private PictureBox pictureBox1;
        private Label label34;
        private Label label2;
    }
}