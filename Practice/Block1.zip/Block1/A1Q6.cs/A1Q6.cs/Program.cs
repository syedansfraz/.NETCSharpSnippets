﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1Q6.cs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string str;
            int wrd, len;

            Console.Write("\n\nCount the total number of words in a string :\n");
            Console.Write("------------------------------------------------------\n");
            Console.Write("Input the string : ");
            str = Console.ReadLine();

            len = 0;
            wrd = 1;
            while (len <= str.Length - 1)
            {
                if (str[len] == ' ' || str[len] == '\n' || str[len] == '\t')
                {
                    wrd++;
                }

                len++;
            }
            Console.Write("Total number of words in the string is : {0}\n", wrd);
            Console.ReadLine();
        }
        
    }
    
    }

