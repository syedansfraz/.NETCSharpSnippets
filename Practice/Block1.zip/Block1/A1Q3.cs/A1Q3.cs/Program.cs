﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1Q3.cs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int flag=1;
            do
            {
                Console.Write("Enter the value b/w 1-7:");
                int num = Convert.ToInt32(Console.ReadLine());
                if (num >= 1 && num <= 7)
                {
                    DayOfWeek day = (DayOfWeek)num;
                    Console.WriteLine("\nDay " + num + " is :" + day);
                }
                else { Console.WriteLine("Please consider the limit of 1-7"); }
                Console.WriteLine("To continue press 1, and 0 for exit");
                int flag2= Convert.ToInt32(Console.ReadLine());
                if (flag2 == 0)
                {
                    flag = 0;
                }
            } while (flag==1);
        }
    }
    public enum DayOfWeek
    {
        Sunday = 1,
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday
    }
}
