﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1Q5.cs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            // Use a list to store even numbers from the array
            // i had no clue about LINQ but after searching i got this
            List<int> evenNumbers = numbers.Where(num => num % 2 == 0).ToList();

            
            int sumOfEven = evenNumbers.Sum();
            Console.WriteLine(sumOfEven);
            Console.ReadLine();
        }
    }
}
