﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1Q1.cs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int number1 = 10;
                int number2 = 0;
                int result = number1 / number2;
                Console.WriteLine("Result: "+result);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Divide by zero exception caught.");
                Console.WriteLine("Message: " + ex.Message);
            }
            Console.ReadLine();
        }
    }
}
