﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1Q2.cs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Library library = new Library();

            // Adding some books to the library
            library.AddBook(new Book("Book 1", "Author 1", 2000));
            library.AddBook(new Book("Book 2", "Author 2", 2010));
            library.AddBook(new Book("Book 3", "Author 3", 1995));

            // Accessing books by title using the indexer
            Console.WriteLine("Book 2 Details:");
            Book book2 = library["Book 2"];
            if (book2 != null)
            {
                Console.WriteLine($"Title: {book2.Title}");
                Console.WriteLine($"Author: {book2.Author}");
                Console.WriteLine($"Publication Year: {book2.PublicationYear}");
                Console.WriteLine($"Age: {book2.Age} years");
            }
            else
            {
                Console.WriteLine("Book not found in the library.");
            }
            Console.ReadLine();
        }

    }
    }
    class Library
    {
        private List<Book> books = new List<Book>();

        // Indexer to access books by their titles
        public Book this[string title]
        {
            get
            {
                return books.Find(book => book.Title == title);
            }
        }

        // Method to add a book to the library
        public void AddBook(Book book)
        {
            books.Add(book);
        }
    }
    class Book
    {
        public string Title;
        public string Author;
        public int PublicationYear;

        // Constructor to initialize the book properties
        public Book(string title, string author, int publicationYear)
        {
            this.Title = title;
            this.Author = author;
            this.PublicationYear = publicationYear;
        }

        // Read-only property to calculate the age of the book
        public int Age
        {
            get
            {
                int currentYear = DateTime.Now.Year;
                return currentYear - PublicationYear;
            }
        }
    }
