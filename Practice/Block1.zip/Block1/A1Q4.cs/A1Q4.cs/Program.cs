﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1Q4.cs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter X-axis for PointA:");
            double ax= Convert.ToDouble(Console.ReadLine());
            Console.Write("\nEnter Y-axis for PointA:");
            double ay = Convert.ToDouble(Console.ReadLine());
            Console.Write("\nEnter X-axis for PointB:");
            double bx = Convert.ToDouble(Console.ReadLine());
            Console.Write("\nEnter Y-axis for PointB:");
            double by = Convert.ToDouble(Console.ReadLine());
            Point2D pointA = new Point2D(ax, ay);
            Point2D pointB = new Point2D(bx, by);
            double distance = Cal(pointA, pointB);

            Console.WriteLine($"Point A: ({pointA.xAxes}, {pointA.yAxes}");
            Console.WriteLine($"Point B: ({pointB.xAxes}, {pointB.yAxes})");
            Console.WriteLine($"Distance between Point A and Point B: {distance:F2}");
        }
        static double Cal(Point2D point1, Point2D point2)
        {
           // d =√((x_2 - x_1)²+(y_2 - y_1)²) This is Distance formula for Two Points
           // and we are going to implement this formula :)
            double deltaX = point1.xAxes - point2.xAxes;
            double deltaY = point1.yAxes - point2.yAxes;
            return Math.Sqrt(deltaX * deltaX + deltaY * deltaY);
        }
    }
    struct Point2D
    {
        public double xAxes;
        public double yAxes;

        public Point2D(double x, double y)
        {
            xAxes = x;
            yAxes = y;
        }
    }
    

    }
