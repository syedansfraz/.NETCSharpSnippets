namespace StringsExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string var = textBox1.Text;
            textBox1.Text = var.ToUpper();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string trimme = textBox2.Text;
            char[] trimchars = { '.' };
            trimme = trimme.TrimEnd(trimchars);
            if(trimme.Contains("@") ) {
                MessageBox.Show("@ is present");
            }
            else
            {
                MessageBox.Show("@ not present");
            }
            //MessageBox.Show(trimme);
        }
    }
}