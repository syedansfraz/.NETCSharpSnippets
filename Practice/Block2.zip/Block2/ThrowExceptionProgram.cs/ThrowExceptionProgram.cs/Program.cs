﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThrowExceptionProgram.cs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Input the size of the array: ");
                int count = Convert.ToInt32(Console.ReadLine());

                int[] numbers = new int[count];

                for (int i = 0; i < count; i++)
                {
                    Console.Write("Input element-{0}: ", i + 1);
                    numbers[i] = Convert.ToInt32(Console.ReadLine());
                }

                double average = CalculateAverage(numbers);

                Console.WriteLine("Average: " + average);
            }
            catch (EmptyArrayException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("Error: Invalid input. Please input integers only.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            Console.ReadLine();
        }

        static double CalculateAverage(int[] numbers)
        {
            if (numbers.Length == 0)
            {
                throw new EmptyArrayException("Array is empty. Cannot calculate average.");
            }

            int sum = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                sum += numbers[i];
            }

            return (double)sum / numbers.Length;
        }
    }

    class EmptyArrayException : Exception
    {
        public EmptyArrayException(string message) : base(message) { }
    }
}
