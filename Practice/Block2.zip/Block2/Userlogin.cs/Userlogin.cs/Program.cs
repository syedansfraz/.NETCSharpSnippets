﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace Userlogin.cs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*int correct = 0;
            int failed = 0;
            Console.WriteLine("--------- Login ---------");
            do
            {
                Console.Write("id:");
                int id = Convert.ToInt32(Console.ReadLine());
                Console.Write("Password:");
                string pass = Console.ReadLine();
                if (id == 123 && pass == "ans")
                {
                    correct++;
                    break;
                }
                else
                    failed++;
            } while (failed != 3);
            if (correct == 0)
                Console.WriteLine("Login Unsuccessfull");
            else if (correct > 0)
                Console.Write("Login Successfull");
            else
                Console.WriteLine("Kuch bh nhi");
            Console.ReadLine();*/
            Bird animal1 = new Bird();
            shemale shee=new shemale2();
            shee.she();
            animal1.language();
            shee.abab();
            Console.ReadLine();
        }
    }
    abstract class shemale
    {
       public abstract void she();
        public virtual void abab()
        {
            Console.WriteLine("i amm abab");
        }
        
    }
    class shemale2:shemale
    {
        public override void abab()
        {
            Console.WriteLine("i  2nd amm abab");
        }
    
        public override void she()
        {
            Console.WriteLine("Im am shemaleee");

        }
    }
    public class animal
    {
        public  virtual void language()
        {
            Console.WriteLine("bbrrrrr");
        }
    }
    public class Bird :animal
    {
        public override void language()
        {
            Console.WriteLine("Chhuu Chuuu");
        }
    }
    public class SeaAnimal:animal
    {
        public override void language()
        {
            Console.WriteLine("guuurrrr gurrr");
        }
    }

}
