namespace Super_Market_Management_Store
{
    internal static class Program
    {
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new Cashier());
        }
    }
}