﻿using Super_Market_Management_Store.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Azure.Core.HttpHeader;

namespace Super_Market_Management_Store
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }
        DatabaseConnection objConnect;
        string conString;
        DataSet ds3;
        DataRow newRow;
        int MaxRows;
        int inc = 0;
        SqlDataReader dr;
        DataRow dRow;
        string username;
        string password;
        bool status;
        string role;


        private void User_Load(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.user;
            ds3 = objConnect.GetConnection;
            MaxRows = ds3.Tables[0].Rows.Count;
            rolecombobox.Items.Add("Admin");
            rolecombobox.Items.Add("Cashier");
            loaduser();
            //loadproduct();
        }
        public void loaduser()
        {

            dataGridView1.Rows.Clear();
            inc = 0;
            while (inc < MaxRows)
            {
                dRow = ds3.Tables[0].Rows[inc];
                dataGridView1.Rows.Add(dRow.ItemArray);
                inc++;
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void rolecombobox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnsavebrandname_Click(object sender, EventArgs e)
        {
            if (pass1tb.Text == pass2tb.Text)
            {
                if (MessageBox.Show("Are you sure you want to create this user?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    newRow = ds3.Tables[0].NewRow();
                    newRow["username"] = usernametb.Text;
                    newRow["password"] = pass1tb.Text;
                    newRow["role"] = rolecombobox.Text.ToString();
                    ds3.Tables[0].Rows.Add(newRow);
                    try
                    {

                        objConnect.UpdateDatabase(ds3);
                        MaxRows = MaxRows + 1;
                        inc = MaxRows - 1;
                        MessageBox.Show("Database updated");
                    }
                    catch (Exception err)
                    {

                        MessageBox.Show(err.Message);
                    }
                }

            }
            else
            {
                MessageBox.Show("Please rewrite same password!!");
                return;
            }

        }

        private void changepassbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string conStr = Properties.Settings.Default.EmployeesConnectionString;
                SqlConnection con = new SqlConnection(conStr);
                con.Open();
                string query = "SELECT * FROM users WHERE username = @username AND password = @password";
                SqlCommand cmd = new SqlCommand(query, con);

                // Add parameters
                cmd.Parameters.AddWithValue("@username", usernametb2.Text);
                cmd.Parameters.AddWithValue("@password", currentpasstb.Text);

                dr = cmd.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    if (newpasstb.Text != retypepasstb.Text)
                    {
                        con.Close();
                        dr.Close();
                        MessageBox.Show("Please enter correctly");
                        return;

                    }
                    if (newpasstb.Text == retypepasstb.Text)
                    {
                        dr.Close();
                        SqlCommand cmd2 = new SqlCommand("Update users  SET password= @password WHERE username = @username", con);
                        cmd2.Parameters.AddWithValue("@password", newpasstb.Text);
                        cmd2.Parameters.AddWithValue("@username", usernametb2.Text);
                        //MessageBox.Show("Password Updated");
                        cmd2.ExecuteNonQuery();
                        MessageBox.Show("Password Updated");
                        con.Close();
                        dr.Close();
                        usernametb2.Text = "";
                        currentpasstb.Text = "";
                        newpasstb.Text = "";
                        retypepasstb.Text = "";
                    }

                }
                else
                {
                    con.Close();
                    dr.Close();
                    MessageBox.Show("Invalid Username or Password");
                    return;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnclosebrandname_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void closebtn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        int indeRow;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];
            username = row.Cells[0].Value.ToString();
            password = row.Cells[1].Value.ToString();
            role = row.Cells[2].Value.ToString();
            status = Convert.ToBoolean(row.Cells[3].Value.ToString());
        }

        private void btnremove_Click(object sender, EventArgs e)
        {

        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Delete this Account?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                int rowIndex = dataGridView1.CurrentCell.RowIndex;
                dataGridView1.Rows.RemoveAt(rowIndex);
                ds3.Tables[0].Rows[rowIndex].Delete();
                objConnect.UpdateDatabase(ds3);
                MaxRows = ds3.Tables[0].Rows.Count;
            }
        }

        private void donebtn_Click(object sender, EventArgs e)
        {
            if (deactivaterb.Checked)
            {
                if (role != "Admin")
                {
                    if (!status)
                    {
                        MessageBox.Show("Account already deactivated");
                    }
                    else
                    {
                        if (MessageBox.Show("Are you sure you want to Deacitvate this Account?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            try
                            {
                                string conStr = Properties.Settings.Default.EmployeesConnectionString;
                                SqlConnection con = new SqlConnection(conStr);
                                con.Open();
                                string query = "Update users SET isactive=@activation WHERE username = @username AND password = @password";
                                SqlCommand cmd = new SqlCommand(query, con);
                                // Add parameters
                                cmd.Parameters.AddWithValue("@activation", (0));
                                cmd.Parameters.AddWithValue("@username", username);
                                cmd.Parameters.AddWithValue("@password", password);

                                dr = cmd.ExecuteReader();
                                dr.Close();
                                con.Close();
                                loaduser();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                        }
                    }

                }
                else
                {
                    MessageBox.Show("Admin Cannot be deactivated");
                }
            }

            if (activaterb.Checked)
            {
                if (role != "Admin")
                {
                    if (status)
                    {
                        MessageBox.Show("This Cashier is Already Activated");
                    }
                    else
                    {
                        if (MessageBox.Show("Are you sure you want to Acitvate this Account?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            try
                            {
                                string conStr = Properties.Settings.Default.EmployeesConnectionString;
                                SqlConnection con = new SqlConnection(conStr);
                                con.Open();
                                string query = "Update users SET isactive=@activation WHERE username = @username AND password = @password";
                                SqlCommand cmd = new SqlCommand(query, con);
                                // Add parameters
                                cmd.Parameters.AddWithValue("@activation", (1));
                                cmd.Parameters.AddWithValue("@username", username);
                                cmd.Parameters.AddWithValue("@password", password);

                                dr = cmd.ExecuteReader();
                                dr.Close();
                                con.Close();
                                loaduser();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                        }
                    }

                }
                else
                    MessageBox.Show("Admin Always Activated");
            }
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.user;
            ds3 = objConnect.GetConnection;
            MaxRows = ds3.Tables[0].Rows.Count;
            rolecombobox.Items.Add("Admin");
            rolecombobox.Items.Add("Cashier");
            loaduser();
        }
    }
}

