﻿namespace Super_Market_Management_Store
{
    partial class Cashier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cashier));
            timer1 = new System.Windows.Forms.Timer(components);
            paneltitle = new Panel();
            pictureBox2 = new PictureBox();
            lblannouncement = new Label();
            pictureBox1 = new PictureBox();
            lblrole = new Label();
            panellogo = new Panel();
            panelmain = new Panel();
            rightpanel = new Panel();
            btnsetting = new Button();
            btnstoresetting = new Button();
            btnusersetting = new Button();
            panelsubsetting = new Panel();
            panelsidebar = new Panel();
            btncart = new Button();
            btnlogout = new Button();
            btnsales = new Button();
            btnclearcart = new Button();
            btnsearch = new Button();
            timelbl = new Label();
            label1 = new Label();
            label2 = new Label();
            label5 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            label3 = new Label();
            datelbl = new Label();
            timmelbl = new Label();
            timer2 = new System.Windows.Forms.Timer(components);
            paneltitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panellogo.SuspendLayout();
            panelmain.SuspendLayout();
            panelsubsetting.SuspendLayout();
            panelsidebar.SuspendLayout();
            SuspendLayout();
            // 
            // timer1
            // 
            timer1.Interval = 10;
            // 
            // paneltitle
            // 
            paneltitle.BackColor = SystemColors.ButtonHighlight;
            paneltitle.Controls.Add(pictureBox2);
            paneltitle.Controls.Add(lblannouncement);
            paneltitle.Dock = DockStyle.Top;
            paneltitle.Location = new Point(257, 0);
            paneltitle.Name = "paneltitle";
            paneltitle.Size = new Size(847, 60);
            paneltitle.TabIndex = 4;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(10, 8);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(61, 45);
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // lblannouncement
            // 
            lblannouncement.BackColor = Color.White;
            lblannouncement.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblannouncement.ForeColor = Color.Red;
            lblannouncement.ImageAlign = ContentAlignment.MiddleRight;
            lblannouncement.Location = new Point(77, 13);
            lblannouncement.Name = "lblannouncement";
            lblannouncement.Size = new Size(721, 38);
            lblannouncement.TabIndex = 0;
            lblannouncement.Text = "Announcements!";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(89, 40);
            pictureBox1.Margin = new Padding(4, 5, 4, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(73, 80);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // lblrole
            // 
            lblrole.AutoSize = true;
            lblrole.BackColor = Color.White;
            lblrole.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblrole.ForeColor = Color.Teal;
            lblrole.Location = new Point(76, 125);
            lblrole.Margin = new Padding(4, 0, 4, 0);
            lblrole.Name = "lblrole";
            lblrole.Size = new Size(97, 32);
            lblrole.TabIndex = 1;
            lblrole.Text = "Cashier";
            // 
            // panellogo
            // 
            panellogo.Controls.Add(pictureBox1);
            panellogo.Controls.Add(lblrole);
            panellogo.Controls.Add(panelmain);
            panellogo.Location = new Point(0, 3);
            panellogo.Name = "panellogo";
            panellogo.Size = new Size(257, 187);
            panellogo.TabIndex = 1;
            // 
            // panelmain
            // 
            panelmain.BackColor = Color.White;
            panelmain.Controls.Add(rightpanel);
            panelmain.Location = new Point(257, 63);
            panelmain.Name = "panelmain";
            panelmain.Padding = new Padding(30, 0, 0, 0);
            panelmain.Size = new Size(728, 636);
            panelmain.TabIndex = 5;
            // 
            // rightpanel
            // 
            rightpanel.Dock = DockStyle.Right;
            rightpanel.Location = new Point(519, 0);
            rightpanel.Name = "rightpanel";
            rightpanel.Size = new Size(209, 636);
            rightpanel.TabIndex = 0;
            // 
            // btnsetting
            // 
            btnsetting.FlatAppearance.BorderSize = 0;
            btnsetting.FlatStyle = FlatStyle.Flat;
            btnsetting.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnsetting.ForeColor = Color.Salmon;
            btnsetting.Location = new Point(1, 707);
            btnsetting.Name = "btnsetting";
            btnsetting.Padding = new Padding(10, 0, 0, 0);
            btnsetting.Size = new Size(257, 42);
            btnsetting.TabIndex = 7;
            btnsetting.Text = "Setting";
            btnsetting.TextAlign = ContentAlignment.MiddleLeft;
            btnsetting.UseVisualStyleBackColor = true;
            // 
            // btnstoresetting
            // 
            btnstoresetting.BackColor = Color.WhiteSmoke;
            btnstoresetting.FlatAppearance.BorderSize = 0;
            btnstoresetting.FlatStyle = FlatStyle.Flat;
            btnstoresetting.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnstoresetting.ForeColor = Color.Salmon;
            btnstoresetting.Location = new Point(1, 47);
            btnstoresetting.Name = "btnstoresetting";
            btnstoresetting.Padding = new Padding(30, 0, 0, 0);
            btnstoresetting.Size = new Size(257, 38);
            btnstoresetting.TabIndex = 6;
            btnstoresetting.Text = "Store";
            btnstoresetting.TextAlign = ContentAlignment.MiddleLeft;
            btnstoresetting.UseVisualStyleBackColor = false;
            // 
            // btnusersetting
            // 
            btnusersetting.BackColor = Color.WhiteSmoke;
            btnusersetting.FlatAppearance.BorderSize = 0;
            btnusersetting.FlatStyle = FlatStyle.Flat;
            btnusersetting.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnusersetting.ForeColor = Color.Salmon;
            btnusersetting.Location = new Point(0, 3);
            btnusersetting.Name = "btnusersetting";
            btnusersetting.Padding = new Padding(30, 0, 0, 0);
            btnusersetting.Size = new Size(257, 47);
            btnusersetting.TabIndex = 5;
            btnusersetting.Text = "User";
            btnusersetting.TextAlign = ContentAlignment.MiddleLeft;
            btnusersetting.UseVisualStyleBackColor = false;
            // 
            // panelsubsetting
            // 
            panelsubsetting.Controls.Add(btnstoresetting);
            panelsubsetting.Controls.Add(btnusersetting);
            panelsubsetting.Location = new Point(1, 755);
            panelsubsetting.Name = "panelsubsetting";
            panelsubsetting.Size = new Size(257, 85);
            panelsubsetting.TabIndex = 1;
            // 
            // panelsidebar
            // 
            panelsidebar.BackColor = Color.White;
            panelsidebar.Controls.Add(btncart);
            panelsidebar.Controls.Add(btnlogout);
            panelsidebar.Controls.Add(btnsales);
            panelsidebar.Controls.Add(btnclearcart);
            panelsidebar.Controls.Add(btnsearch);
            panelsidebar.Controls.Add(panelsubsetting);
            panelsidebar.Controls.Add(btnsetting);
            panelsidebar.Controls.Add(panellogo);
            panelsidebar.Dock = DockStyle.Left;
            panelsidebar.Location = new Point(0, 0);
            panelsidebar.Name = "panelsidebar";
            panelsidebar.Size = new Size(257, 701);
            panelsidebar.TabIndex = 3;
            // 
            // btncart
            // 
            btncart.FlatAppearance.BorderSize = 0;
            btncart.FlatStyle = FlatStyle.Flat;
            btncart.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btncart.ForeColor = Color.Teal;
            btncart.Location = new Point(4, 251);
            btncart.Name = "btncart";
            btncart.Padding = new Padding(10, 0, 0, 0);
            btncart.Size = new Size(251, 59);
            btncart.TabIndex = 16;
            btncart.Text = "Cart";
            btncart.TextAlign = ContentAlignment.MiddleLeft;
            btncart.UseVisualStyleBackColor = true;
            btncart.Click += btncart_Click;
            // 
            // btnlogout
            // 
            btnlogout.FlatAppearance.BorderSize = 0;
            btnlogout.FlatStyle = FlatStyle.Flat;
            btnlogout.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnlogout.ForeColor = Color.Teal;
            btnlogout.Image = (Image)resources.GetObject("btnlogout.Image");
            btnlogout.ImageAlign = ContentAlignment.MiddleRight;
            btnlogout.Location = new Point(1, 640);
            btnlogout.Name = "btnlogout";
            btnlogout.Padding = new Padding(10, 0, 0, 0);
            btnlogout.Size = new Size(251, 59);
            btnlogout.TabIndex = 14;
            btnlogout.Text = "Logout";
            btnlogout.TextAlign = ContentAlignment.MiddleLeft;
            btnlogout.UseVisualStyleBackColor = true;
            btnlogout.Click += btnlogout_Click;
            // 
            // btnsales
            // 
            btnsales.FlatAppearance.BorderSize = 0;
            btnsales.FlatStyle = FlatStyle.Flat;
            btnsales.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnsales.ForeColor = Color.Teal;
            btnsales.Location = new Point(3, 386);
            btnsales.Name = "btnsales";
            btnsales.Padding = new Padding(10, 0, 0, 0);
            btnsales.Size = new Size(251, 59);
            btnsales.TabIndex = 12;
            btnsales.Text = "Daily Sales";
            btnsales.TextAlign = ContentAlignment.MiddleLeft;
            btnsales.UseVisualStyleBackColor = true;
            btnsales.Click += btnsales_Click;
            // 
            // btnclearcart
            // 
            btnclearcart.FlatAppearance.BorderSize = 0;
            btnclearcart.FlatStyle = FlatStyle.Flat;
            btnclearcart.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnclearcart.ForeColor = Color.Teal;
            btnclearcart.Location = new Point(3, 317);
            btnclearcart.Name = "btnclearcart";
            btnclearcart.Padding = new Padding(10, 0, 0, 0);
            btnclearcart.Size = new Size(251, 59);
            btnclearcart.TabIndex = 11;
            btnclearcart.Text = "Clear Cart";
            btnclearcart.TextAlign = ContentAlignment.MiddleLeft;
            btnclearcart.UseVisualStyleBackColor = true;
            btnclearcart.Click += btnclearcart_Click;
            // 
            // btnsearch
            // 
            btnsearch.FlatAppearance.BorderSize = 0;
            btnsearch.FlatStyle = FlatStyle.Flat;
            btnsearch.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnsearch.ForeColor = Color.Teal;
            btnsearch.Location = new Point(3, 191);
            btnsearch.Name = "btnsearch";
            btnsearch.Padding = new Padding(10, 0, 0, 0);
            btnsearch.Size = new Size(251, 59);
            btnsearch.TabIndex = 9;
            btnsearch.Text = "Search Product";
            btnsearch.TextAlign = ContentAlignment.MiddleLeft;
            btnsearch.UseVisualStyleBackColor = true;
            btnsearch.Click += btnsearch_Click;
            // 
            // timelbl
            // 
            timelbl.BackColor = Color.Teal;
            timelbl.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            timelbl.ForeColor = SystemColors.ButtonHighlight;
            timelbl.Location = new Point(290, 99);
            timelbl.Name = "timelbl";
            timelbl.Size = new Size(95, 64);
            timelbl.TabIndex = 7;
            timelbl.Text = "Rules";
            timelbl.TextAlign = ContentAlignment.MiddleLeft;
            timelbl.Click += timelbl_Click;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(290, 180);
            label1.Name = "label1";
            label1.Size = new Size(362, 70);
            label1.TabIndex = 8;
            label1.Text = "Ensure accurate and secure handling of transactions.";
            // 
            // label2
            // 
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(290, 340);
            label2.Name = "label2";
            label2.Size = new Size(362, 70);
            label2.TabIndex = 9;
            label2.Text = "Count cash accurately, follow cash handling procedures.";
            // 
            // label5
            // 
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(290, 260);
            label5.Name = "label5";
            label5.Size = new Size(362, 70);
            label5.TabIndex = 12;
            label5.Text = "Provide excellent customer service with a positive attitude.";
            // 
            // label7
            // 
            label7.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(290, 580);
            label7.Name = "label7";
            label7.Size = new Size(362, 70);
            label7.TabIndex = 14;
            label7.Text = "Keep the cashier area clean and follow hygiene protocols.";
            // 
            // label8
            // 
            label8.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(290, 420);
            label8.Name = "label8";
            label8.Size = new Size(362, 70);
            label8.TabIndex = 15;
            label8.Text = "Issue accurate receipts, maintain organized transaction records.";
            // 
            // label9
            // 
            label9.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(290, 500);
            label9.Name = "label9";
            label9.Size = new Size(362, 70);
            label9.TabIndex = 16;
            label9.Text = "Stay informed about products, prices, and promotions.";
            label9.Click += label9_Click;
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // label3
            // 
            label3.BackColor = Color.Teal;
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(681, 63);
            label3.Name = "label3";
            label3.Size = new Size(20, 636);
            label3.TabIndex = 17;
            label3.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // datelbl
            // 
            datelbl.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            datelbl.ForeColor = SystemColors.ActiveCaptionText;
            datelbl.Location = new Point(731, 369);
            datelbl.Name = "datelbl";
            datelbl.Size = new Size(346, 64);
            datelbl.TabIndex = 19;
            datelbl.Text = "Date:";
            datelbl.TextAlign = ContentAlignment.MiddleLeft;
            datelbl.Click += datelbl_Click;
            // 
            // timmelbl
            // 
            timmelbl.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            timmelbl.ForeColor = SystemColors.ActiveCaptionText;
            timmelbl.Location = new Point(779, 306);
            timmelbl.Name = "timmelbl";
            timmelbl.Size = new Size(247, 64);
            timmelbl.TabIndex = 18;
            timmelbl.Text = "Time:";
            timmelbl.TextAlign = ContentAlignment.MiddleCenter;
            timmelbl.Click += label4_Click;
            // 
            // timer2
            // 
            timer2.Tick += timer2_Tick;
            // 
            // Cashier
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(1104, 701);
            Controls.Add(datelbl);
            Controls.Add(timmelbl);
            Controls.Add(label3);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(timelbl);
            Controls.Add(paneltitle);
            Controls.Add(panelsidebar);
            Name = "Cashier";
            Text = "Cashier";
            Load += Cashier_Load;
            paneltitle.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panellogo.ResumeLayout(false);
            panellogo.PerformLayout();
            panelmain.ResumeLayout(false);
            panelsubsetting.ResumeLayout(false);
            panelsidebar.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private Panel paneltitle;
        private Label lblannouncement;
        private PictureBox pictureBox1;
        private Label lblrole;
        private Panel panellogo;
        private Button btnsetting;
        private Button btnstoresetting;
        private Button btnusersetting;
        private Panel panelsubsetting;
        private Panel panelsidebar;
        private Panel panelmain;
        private Button btnlogout;
        private Button btnsales;
        private Button btnclearcart;
        private Button btnsearch;
        private Panel rightpanel;
        private Button btncart;
        private Label timelbl;
        private Label label1;
        private Label label2;
        private Label label5;
        private Label label7;
        private Label label8;
        private Label label9;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private Label label3;
        private Label datelbl;
        private Label timmelbl;
        private System.Windows.Forms.Timer timer2;
        private PictureBox pictureBox2;
    }
}