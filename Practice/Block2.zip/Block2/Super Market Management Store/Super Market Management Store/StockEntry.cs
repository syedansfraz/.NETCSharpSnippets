﻿using Super_Market_Management_Store.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Super_Market_Management_Store
{
    public partial class StockEntry : Form
    {
        Boolean flag = false;
        public StockEntry()
        {
            InitializeComponent();
        }
        DatabaseConnection objConnect;
        string conString;
        DataSet ds;
        DataRow dRow;
        int MaxRows;
        int inc = 0;
        string quantity;
        int newquantity;
        int rowIndexx;

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void quantitybox_ValueChanged(object sender, EventArgs e)
        {
        }

        private void StockEntry_Load(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.SQL3;
            ds = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
            loadproduct();
        }
        public void loadproduct()
        {
            dataGridView1.Rows.Clear();
            inc = 0;
            while (inc < MaxRows)
            {
                dRow = ds.Tables[0].Rows[inc];
                dataGridView1.Rows.Add(dRow.ItemArray);
                inc++;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            quantity = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
            rowIndexx = e.RowIndex;
        }

        private void btnsavebrandname_Click(object sender, EventArgs e)
        {

        }

        private void btnsavebrandname_Click_1(object sender, EventArgs e)
        {
            DataRow row = ds.Tables[0].Rows[rowIndexx];
            string conStr = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string query = "UPDATE Nameofproduct SET Quantity = Quantity + @newquantity WHERE Id=@productid";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@newquantity", quantitybox.Value);
            cmd.Parameters.AddWithValue("@productid", idtextbox.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Stock Addded");
            loadproduct();
        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }

        private void quantitybox_ValueChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.SQL3;
            ds = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
            loadproduct();
        }
    }
}
