﻿using Super_Market_Management_Store.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Super_Market_Management_Store
{
    public partial class Announce_Here_ : Form
    {
        public Announce_Here_()
        {
            InitializeComponent();
        }
        DatabaseConnection objConnect;
        string conString;
        DataSet ds;
        DataRow dRow;
        int MaxRows;
        int inc = 0;

        private void announcetb_TextChanged(object sender, EventArgs e)
        {

        }

        private void Announce_Here__Load(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.Announcement;
            ds = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
        }

        private void btnsavebrandname_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you Sure You Want to Announce this?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                DataRow row = ds.Tables[0].NewRow();
                row[1] = announcetb.Text;
                ds.Tables[0].Rows.Add(row);
                try
                {

                    objConnect.UpdateDatabase(ds);
                    MaxRows = MaxRows + 1;
                    inc = MaxRows - 1;
                    this.Dispose();

                }
                catch (Exception err)
                {

                    MessageBox.Show(err.Message);

                }
            }
        }
    }
}
