﻿namespace Super_Market_Management_Store
{
    partial class ProductModule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnclosebrandname = new Button();
            btnsavebrandname = new Button();
            label2 = new Label();
            descriptiontb = new TextBox();
            label3 = new Label();
            pricebox = new TextBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            brandcombobox = new ComboBox();
            categorycombobox = new ComboBox();
            quantitybox = new NumericUpDown();
            label1 = new Label();
            barcodetb = new TextBox();
            ((System.ComponentModel.ISupportInitialize)quantitybox).BeginInit();
            SuspendLayout();
            // 
            // btnclosebrandname
            // 
            btnclosebrandname.BackColor = Color.Salmon;
            btnclosebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnclosebrandname.ForeColor = Color.White;
            btnclosebrandname.Location = new Point(599, 318);
            btnclosebrandname.Name = "btnclosebrandname";
            btnclosebrandname.Size = new Size(134, 52);
            btnclosebrandname.TabIndex = 10;
            btnclosebrandname.Text = "Close";
            btnclosebrandname.UseVisualStyleBackColor = false;
            btnclosebrandname.Click += btnclosebrandname_Click;
            // 
            // btnsavebrandname
            // 
            btnsavebrandname.BackColor = Color.Salmon;
            btnsavebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnsavebrandname.ForeColor = Color.White;
            btnsavebrandname.Location = new Point(414, 318);
            btnsavebrandname.Name = "btnsavebrandname";
            btnsavebrandname.Size = new Size(134, 52);
            btnsavebrandname.TabIndex = 9;
            btnsavebrandname.Text = "Save";
            btnsavebrandname.UseVisualStyleBackColor = false;
            btnsavebrandname.Click += btnsavebrandname_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Salmon;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(61, 184);
            label2.Name = "label2";
            label2.Size = new Size(95, 25);
            label2.TabIndex = 11;
            label2.Text = "Category:";
            // 
            // descriptiontb
            // 
            descriptiontb.Location = new Point(226, 40);
            descriptiontb.Name = "descriptiontb";
            descriptiontb.Size = new Size(464, 31);
            descriptiontb.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Salmon;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(61, 46);
            label3.Name = "label3";
            label3.Size = new Size(114, 25);
            label3.TabIndex = 13;
            label3.Text = "Description:";
            // 
            // pricebox
            // 
            pricebox.Location = new Point(170, 237);
            pricebox.Name = "pricebox";
            pricebox.Size = new Size(181, 31);
            pricebox.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Salmon;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(61, 240);
            label4.Name = "label4";
            label4.Size = new Size(59, 25);
            label4.TabIndex = 15;
            label4.Text = "Price:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Salmon;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(61, 138);
            label5.Name = "label5";
            label5.Size = new Size(68, 25);
            label5.TabIndex = 17;
            label5.Text = "Brand:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Salmon;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(401, 240);
            label6.Name = "label6";
            label6.Size = new Size(92, 25);
            label6.TabIndex = 19;
            label6.Text = "Quantity:";
            // 
            // brandcombobox
            // 
            brandcombobox.FormattingEnabled = true;
            brandcombobox.Location = new Point(226, 132);
            brandcombobox.Name = "brandcombobox";
            brandcombobox.Size = new Size(464, 33);
            brandcombobox.TabIndex = 3;
            brandcombobox.SelectedIndexChanged += brandcombobox_SelectedIndexChanged;
            // 
            // categorycombobox
            // 
            categorycombobox.FormattingEnabled = true;
            categorycombobox.Location = new Point(226, 180);
            categorycombobox.Name = "categorycombobox";
            categorycombobox.Size = new Size(464, 33);
            categorycombobox.TabIndex = 4;
            // 
            // quantitybox
            // 
            quantitybox.Location = new Point(543, 233);
            quantitybox.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            quantitybox.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            quantitybox.Name = "quantitybox";
            quantitybox.Size = new Size(147, 31);
            quantitybox.TabIndex = 6;
            quantitybox.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Salmon;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(61, 92);
            label1.Name = "label1";
            label1.Size = new Size(87, 25);
            label1.TabIndex = 24;
            label1.Text = "Barcode:";
            // 
            // barcodetb
            // 
            barcodetb.Location = new Point(226, 86);
            barcodetb.Name = "barcodetb";
            barcodetb.Size = new Size(464, 31);
            barcodetb.TabIndex = 2;
            // 
            // ProductModule
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 393);
            Controls.Add(barcodetb);
            Controls.Add(label1);
            Controls.Add(quantitybox);
            Controls.Add(categorycombobox);
            Controls.Add(brandcombobox);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(pricebox);
            Controls.Add(label4);
            Controls.Add(descriptiontb);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnclosebrandname);
            Controls.Add(btnsavebrandname);
            Name = "ProductModule";
            Text = "Product Module";
            Load += ProductModule_Load;
            ((System.ComponentModel.ISupportInitialize)quantitybox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnclosebrandname;
        private Button btnsavebrandname;
        private Label label2;
        private TextBox descriptiontb;
        private Label label3;
        private TextBox pricebox;
        private Label label4;
        private Label label5;
        private Label label6;
        private ComboBox brandcombobox;
        private ComboBox categorycombobox;
        private NumericUpDown quantitybox;
        private Label label1;
        private TextBox barcodetb;
    }
}