﻿namespace Super_Market_Management_Store
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(login));
            nametb = new TextBox();
            passwrdtb = new TextBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            btnsavebrandname = new Button();
            submitbtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // nametb
            // 
            nametb.Location = new Point(238, 338);
            nametb.Name = "nametb";
            nametb.PlaceholderText = "Username";
            nametb.Size = new Size(266, 31);
            nametb.TabIndex = 0;
            // 
            // passwrdtb
            // 
            passwrdtb.Location = new Point(241, 387);
            passwrdtb.Name = "passwrdtb";
            passwrdtb.PlaceholderText = "Password";
            passwrdtb.Size = new Size(266, 31);
            passwrdtb.TabIndex = 1;
            passwrdtb.UseSystemPasswordChar = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(247, 41);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(245, 249);
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.Image = (Image)resources.GetObject("label1.Image");
            label1.Location = new Point(206, 336);
            label1.Name = "label1";
            label1.Size = new Size(26, 33);
            label1.TabIndex = 4;
            // 
            // label2
            // 
            label2.Image = (Image)resources.GetObject("label2.Image");
            label2.Location = new Point(206, 390);
            label2.Name = "label2";
            label2.Size = new Size(26, 33);
            label2.TabIndex = 5;
            // 
            // btnsavebrandname
            // 
            btnsavebrandname.BackColor = Color.Red;
            btnsavebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnsavebrandname.ForeColor = Color.White;
            btnsavebrandname.Location = new Point(238, 495);
            btnsavebrandname.Name = "btnsavebrandname";
            btnsavebrandname.Size = new Size(266, 52);
            btnsavebrandname.TabIndex = 3;
            btnsavebrandname.Text = "Cancel";
            btnsavebrandname.UseVisualStyleBackColor = false;
            btnsavebrandname.Click += btnsavebrandname_Click;
            // 
            // submitbtn
            // 
            submitbtn.BackColor = Color.Teal;
            submitbtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            submitbtn.ForeColor = Color.White;
            submitbtn.Location = new Point(238, 437);
            submitbtn.Name = "submitbtn";
            submitbtn.Size = new Size(266, 52);
            submitbtn.TabIndex = 2;
            submitbtn.Text = "Login";
            submitbtn.UseVisualStyleBackColor = false;
            submitbtn.Click += submitbtn_Click_1;
            // 
            // login
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(724, 564);
            Controls.Add(submitbtn);
            Controls.Add(btnsavebrandname);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(passwrdtb);
            Controls.Add(nametb);
            Name = "login";
            Text = "login";
            Load += login_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox nametb;
        private TextBox passwrdtb;
        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Button btnsavebrandname;
        private Button submitbtn;
    }
}