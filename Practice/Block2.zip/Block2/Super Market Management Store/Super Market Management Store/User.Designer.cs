﻿namespace Super_Market_Management_Store
{
    partial class User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            pass1tb = new TextBox();
            pass2tb = new TextBox();
            rolecombobox = new ComboBox();
            btnsavebrandname = new Button();
            label4 = new Label();
            label2 = new Label();
            label1 = new Label();
            usernametb = new TextBox();
            label3 = new Label();
            tabPage2 = new TabPage();
            retypepasstb = new TextBox();
            label9 = new Label();
            changepassbtn = new Button();
            newpasstb = new TextBox();
            label6 = new Label();
            currentpasstb = new TextBox();
            label7 = new Label();
            usernametb2 = new TextBox();
            label8 = new Label();
            tabPage3 = new TabPage();
            button2 = new Button();
            donebtn = new Button();
            deactivaterb = new RadioButton();
            activaterb = new RadioButton();
            button1 = new Button();
            btnclose = new Button();
            dataGridView1 = new DataGridView();
            Cashier = new DataGridViewTextBoxColumn();
            Password = new DataGridViewTextBoxColumn();
            Role = new DataGridViewTextBoxColumn();
            Status = new DataGridViewTextBoxColumn();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new Point(12, 29);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(866, 487);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = SystemColors.ButtonHighlight;
            tabPage1.Controls.Add(pass1tb);
            tabPage1.Controls.Add(pass2tb);
            tabPage1.Controls.Add(rolecombobox);
            tabPage1.Controls.Add(btnsavebrandname);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(usernametb);
            tabPage1.Controls.Add(label3);
            tabPage1.Location = new Point(4, 34);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(858, 449);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Create Account";
            tabPage1.Click += tabPage1_Click;
            // 
            // pass1tb
            // 
            pass1tb.Location = new Point(280, 129);
            pass1tb.Name = "pass1tb";
            pass1tb.Size = new Size(464, 31);
            pass1tb.TabIndex = 2;
            pass1tb.UseSystemPasswordChar = true;
            // 
            // pass2tb
            // 
            pass2tb.Location = new Point(280, 209);
            pass2tb.Name = "pass2tb";
            pass2tb.Size = new Size(464, 31);
            pass2tb.TabIndex = 3;
            pass2tb.UseSystemPasswordChar = true;
            // 
            // rolecombobox
            // 
            rolecombobox.FormattingEnabled = true;
            rolecombobox.Location = new Point(280, 283);
            rolecombobox.Name = "rolecombobox";
            rolecombobox.Size = new Size(464, 33);
            rolecombobox.TabIndex = 4;
            rolecombobox.SelectedIndexChanged += rolecombobox_SelectedIndexChanged;
            // 
            // btnsavebrandname
            // 
            btnsavebrandname.BackColor = Color.Salmon;
            btnsavebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnsavebrandname.ForeColor = Color.White;
            btnsavebrandname.Location = new Point(610, 356);
            btnsavebrandname.Name = "btnsavebrandname";
            btnsavebrandname.Size = new Size(134, 52);
            btnsavebrandname.TabIndex = 22;
            btnsavebrandname.Text = "Save";
            btnsavebrandname.UseVisualStyleBackColor = false;
            btnsavebrandname.Click += btnsavebrandname_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Salmon;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(115, 290);
            label4.Name = "label4";
            label4.Size = new Size(55, 25);
            label4.TabIndex = 21;
            label4.Text = "Role:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Salmon;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(115, 209);
            label2.Name = "label2";
            label2.Size = new Size(126, 25);
            label2.TabIndex = 19;
            label2.Text = "Re-type Pass:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Salmon;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(115, 135);
            label1.Name = "label1";
            label1.Size = new Size(97, 25);
            label1.TabIndex = 17;
            label1.Text = "Password:";
            // 
            // usernametb
            // 
            usernametb.Location = new Point(280, 55);
            usernametb.Name = "usernametb";
            usernametb.Size = new Size(464, 31);
            usernametb.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Salmon;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(115, 61);
            label3.Name = "label3";
            label3.Size = new Size(102, 25);
            label3.TabIndex = 15;
            label3.Text = "Username:";
            // 
            // tabPage2
            // 
            tabPage2.BackColor = SystemColors.ButtonHighlight;
            tabPage2.Controls.Add(retypepasstb);
            tabPage2.Controls.Add(label9);
            tabPage2.Controls.Add(changepassbtn);
            tabPage2.Controls.Add(newpasstb);
            tabPage2.Controls.Add(label6);
            tabPage2.Controls.Add(currentpasstb);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(usernametb2);
            tabPage2.Controls.Add(label8);
            tabPage2.Location = new Point(4, 34);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(858, 449);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Change password";
            // 
            // retypepasstb
            // 
            retypepasstb.Location = new Point(280, 285);
            retypepasstb.Name = "retypepasstb";
            retypepasstb.Size = new Size(464, 31);
            retypepasstb.TabIndex = 36;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Salmon;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(115, 291);
            label9.Name = "label9";
            label9.Size = new Size(126, 25);
            label9.TabIndex = 35;
            label9.Text = "Re-type Pass:";
            // 
            // changepassbtn
            // 
            changepassbtn.BackColor = Color.Salmon;
            changepassbtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            changepassbtn.ForeColor = Color.White;
            changepassbtn.Location = new Point(610, 360);
            changepassbtn.Name = "changepassbtn";
            changepassbtn.Size = new Size(134, 52);
            changepassbtn.TabIndex = 32;
            changepassbtn.Text = "Update";
            changepassbtn.UseVisualStyleBackColor = false;
            changepassbtn.Click += changepassbtn_Click;
            // 
            // newpasstb
            // 
            newpasstb.Location = new Point(280, 207);
            newpasstb.Name = "newpasstb";
            newpasstb.Size = new Size(464, 31);
            newpasstb.TabIndex = 29;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Salmon;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(115, 209);
            label6.Name = "label6";
            label6.Size = new Size(140, 25);
            label6.TabIndex = 30;
            label6.Text = "New Password:";
            // 
            // currentpasstb
            // 
            currentpasstb.Location = new Point(280, 131);
            currentpasstb.Name = "currentpasstb";
            currentpasstb.Size = new Size(464, 31);
            currentpasstb.TabIndex = 27;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Salmon;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(115, 135);
            label7.Name = "label7";
            label7.Size = new Size(123, 25);
            label7.TabIndex = 28;
            label7.Text = "Current Pass:";
            // 
            // usernametb2
            // 
            usernametb2.Location = new Point(280, 55);
            usernametb2.Name = "usernametb2";
            usernametb2.Size = new Size(464, 31);
            usernametb2.TabIndex = 25;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Salmon;
            label8.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(115, 61);
            label8.Name = "label8";
            label8.Size = new Size(102, 25);
            label8.TabIndex = 26;
            label8.Text = "Username:";
            // 
            // tabPage3
            // 
            tabPage3.BackColor = SystemColors.ButtonHighlight;
            tabPage3.Controls.Add(button2);
            tabPage3.Controls.Add(donebtn);
            tabPage3.Controls.Add(deactivaterb);
            tabPage3.Controls.Add(activaterb);
            tabPage3.Controls.Add(button1);
            tabPage3.Controls.Add(btnclose);
            tabPage3.Controls.Add(dataGridView1);
            tabPage3.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            tabPage3.ForeColor = SystemColors.ActiveCaption;
            tabPage3.Location = new Point(4, 34);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(858, 449);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Active/Unactive Account";
            tabPage3.Click += tabPage3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Olive;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.White;
            button2.Location = new Point(668, 384);
            button2.Name = "button2";
            button2.Size = new Size(116, 52);
            button2.TabIndex = 13;
            button2.Text = "Refresh";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // donebtn
            // 
            donebtn.BackColor = Color.Teal;
            donebtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            donebtn.ForeColor = Color.White;
            donebtn.Location = new Point(404, 384);
            donebtn.Name = "donebtn";
            donebtn.Size = new Size(116, 52);
            donebtn.TabIndex = 12;
            donebtn.Text = "Done";
            donebtn.UseVisualStyleBackColor = false;
            donebtn.Click += donebtn_Click;
            // 
            // deactivaterb
            // 
            deactivaterb.AutoSize = true;
            deactivaterb.BackColor = SystemColors.ButtonHighlight;
            deactivaterb.ForeColor = SystemColors.ActiveCaptionText;
            deactivaterb.Location = new Point(189, 391);
            deactivaterb.Name = "deactivaterb";
            deactivaterb.Size = new Size(181, 45);
            deactivaterb.TabIndex = 11;
            deactivaterb.Text = "Deactivate";
            deactivaterb.UseVisualStyleBackColor = false;
            // 
            // activaterb
            // 
            activaterb.AutoSize = true;
            activaterb.BackColor = SystemColors.ButtonHighlight;
            activaterb.ForeColor = SystemColors.ActiveCaptionText;
            activaterb.Location = new Point(35, 391);
            activaterb.Name = "activaterb";
            activaterb.Size = new Size(148, 45);
            activaterb.TabIndex = 10;
            activaterb.Text = "Activate";
            activaterb.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.Location = new Point(733, 448);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 9;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            // 
            // btnclose
            // 
            btnclose.BackColor = Color.Red;
            btnclose.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnclose.ForeColor = Color.White;
            btnclose.Location = new Point(526, 384);
            btnclose.Name = "btnclose";
            btnclose.Size = new Size(136, 52);
            btnclose.TabIndex = 5;
            btnclose.Text = "Remove";
            btnclose.UseVisualStyleBackColor = false;
            btnclose.Click += btnclose_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Salmon;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = Color.Salmon;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Cashier, Password, Role, Status });
            dataGridView1.Dock = DockStyle.Top;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = Color.WhiteSmoke;
            dataGridView1.Location = new Point(3, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.Teal;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = Color.Salmon;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(852, 318);
            dataGridView1.TabIndex = 8;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Cashier
            // 
            Cashier.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle2.ForeColor = Color.Black;
            Cashier.DefaultCellStyle = dataGridViewCellStyle2;
            Cashier.HeaderText = "UserName";
            Cashier.MinimumWidth = 8;
            Cashier.Name = "Cashier";
            Cashier.ReadOnly = true;
            // 
            // Password
            // 
            Password.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle3.ForeColor = Color.Black;
            Password.DefaultCellStyle = dataGridViewCellStyle3;
            Password.HeaderText = "Password";
            Password.MinimumWidth = 8;
            Password.Name = "Password";
            // 
            // Role
            // 
            dataGridViewCellStyle4.ForeColor = Color.Black;
            Role.DefaultCellStyle = dataGridViewCellStyle4;
            Role.HeaderText = "Role";
            Role.MinimumWidth = 8;
            Role.Name = "Role";
            Role.Width = 150;
            // 
            // Status
            // 
            Status.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle5.ForeColor = Color.Black;
            Status.DefaultCellStyle = dataGridViewCellStyle5;
            Status.HeaderText = "Status";
            Status.MinimumWidth = 8;
            Status.Name = "Status";
            Status.ReadOnly = true;
            Status.Width = 134;
            // 
            // User
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(890, 592);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "User";
            Text = "User";
            Load += User_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private Label label4;
        private Label label2;
        private Label label1;
        private TextBox usernametb;
        private Label label3;
        private ComboBox rolecombobox;
        private Button btnsavebrandname;
        private Button changepassbtn;
        private TextBox newpasstb;
        private Label label6;
        private TextBox currentpasstb;
        private Label label7;
        private TextBox usernametb2;
        private Label label8;
        private TextBox retypepasstb;
        private Label label9;
        private DataGridView dataGridView1;
        private TextBox pass2tb;
        private TextBox pass1tb;
        private DataGridViewTextBoxColumn Cashier;
        private DataGridViewTextBoxColumn Password;
        private DataGridViewTextBoxColumn Role;
        private DataGridViewTextBoxColumn Status;
        private Button btnclose;
        private Button button1;
        private RadioButton deactivaterb;
        private RadioButton activaterb;
        private Button donebtn;
        private Button button2;
    }
}