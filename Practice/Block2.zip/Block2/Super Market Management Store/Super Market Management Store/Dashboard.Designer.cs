﻿namespace Super_Market_Management_Store
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            greetinglbl = new Label();
            timinglbl = new Label();
            label1 = new Label();
            checkedListBox1 = new CheckedListBox();
            textBox1 = new TextBox();
            newtaskbtn = new Button();
            timelbl = new Label();
            datelbl = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            qoutelbl = new Label();
            label3 = new Label();
            POS1 = new Label();
            totalproductlbl = new Label();
            label2 = new Label();
            earninglbl = new Label();
            label4 = new Label();
            productslbl = new Label();
            SuspendLayout();
            // 
            // greetinglbl
            // 
            greetinglbl.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            greetinglbl.ForeColor = Color.Salmon;
            greetinglbl.Location = new Point(80, 9);
            greetinglbl.Name = "greetinglbl";
            greetinglbl.Size = new Size(307, 64);
            greetinglbl.TabIndex = 0;
            greetinglbl.Text = "label1";
            greetinglbl.TextAlign = ContentAlignment.MiddleLeft;
            greetinglbl.Click += greetinglbl_Click;
            // 
            // timinglbl
            // 
            timinglbl.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            timinglbl.ForeColor = Color.Teal;
            timinglbl.Location = new Point(443, 9);
            timinglbl.Name = "timinglbl";
            timinglbl.Size = new Size(372, 64);
            timinglbl.TabIndex = 1;
            timinglbl.Text = "label1";
            timinglbl.TextAlign = ContentAlignment.MiddleCenter;
            timinglbl.Click += timinglbl_Click;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(105, 269);
            label1.Name = "label1";
            label1.Size = new Size(247, 64);
            label1.TabIndex = 2;
            label1.Text = "Everyday Tasks";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // checkedListBox1
            // 
            checkedListBox1.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Items.AddRange(new object[] { "Check Daily Reports", "Add New Stock", "Profit/Loss Calculation" });
            checkedListBox1.Location = new Point(105, 346);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(247, 283);
            checkedListBox1.TabIndex = 3;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(105, 664);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(247, 31);
            textBox1.TabIndex = 1;
            // 
            // newtaskbtn
            // 
            newtaskbtn.BackColor = Color.Teal;
            newtaskbtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            newtaskbtn.ForeColor = Color.White;
            newtaskbtn.Location = new Point(105, 701);
            newtaskbtn.Name = "newtaskbtn";
            newtaskbtn.Size = new Size(247, 52);
            newtaskbtn.TabIndex = 5;
            newtaskbtn.Text = "New Task";
            newtaskbtn.UseVisualStyleBackColor = false;
            newtaskbtn.Click += newtaskbtn_Click;
            // 
            // timelbl
            // 
            timelbl.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            timelbl.ForeColor = SystemColors.ActiveCaptionText;
            timelbl.Location = new Point(489, 622);
            timelbl.Name = "timelbl";
            timelbl.Size = new Size(247, 64);
            timelbl.TabIndex = 6;
            timelbl.Text = "Time:";
            timelbl.TextAlign = ContentAlignment.MiddleCenter;
            timelbl.Click += timelbl_Click;
            // 
            // datelbl
            // 
            datelbl.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            datelbl.ForeColor = SystemColors.ActiveCaptionText;
            datelbl.Location = new Point(441, 685);
            datelbl.Name = "datelbl";
            datelbl.Size = new Size(346, 64);
            datelbl.TabIndex = 7;
            datelbl.Text = "Date:";
            datelbl.TextAlign = ContentAlignment.MiddleLeft;
            datelbl.Click += datelbl_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // qoutelbl
            // 
            qoutelbl.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            qoutelbl.ForeColor = Color.Teal;
            qoutelbl.Location = new Point(398, 346);
            qoutelbl.Name = "qoutelbl";
            qoutelbl.Size = new Size(407, 276);
            qoutelbl.TabIndex = 8;
            qoutelbl.Text = "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhjjjjjjjjjjjjjjjjjkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk";
            qoutelbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(469, 269);
            label3.Name = "label3";
            label3.Size = new Size(290, 64);
            label3.TabIndex = 9;
            label3.Text = "Quote of the Day";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // POS1
            // 
            POS1.BackColor = Color.Teal;
            POS1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            POS1.ForeColor = SystemColors.ButtonHighlight;
            POS1.Image = (Image)resources.GetObject("POS1.Image");
            POS1.ImageAlign = ContentAlignment.TopRight;
            POS1.Location = new Point(327, 104);
            POS1.Name = "POS1";
            POS1.Padding = new Padding(5, 10, 0, 0);
            POS1.Size = new Size(241, 142);
            POS1.TabIndex = 10;
            POS1.Text = "Inventory";
            POS1.Click += POS1_Click;
            // 
            // totalproductlbl
            // 
            totalproductlbl.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            totalproductlbl.ForeColor = Color.Teal;
            totalproductlbl.Location = new Point(342, 181);
            totalproductlbl.Name = "totalproductlbl";
            totalproductlbl.Size = new Size(75, 38);
            totalproductlbl.TabIndex = 13;
            totalproductlbl.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            label2.BackColor = Color.Teal;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Image = (Image)resources.GetObject("label2.Image");
            label2.ImageAlign = ContentAlignment.TopRight;
            label2.Location = new Point(574, 104);
            label2.Name = "label2";
            label2.Padding = new Padding(5, 10, 0, 0);
            label2.Size = new Size(241, 142);
            label2.TabIndex = 14;
            label2.Text = "Earnings";
            // 
            // earninglbl
            // 
            earninglbl.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            earninglbl.ForeColor = Color.Teal;
            earninglbl.Location = new Point(584, 181);
            earninglbl.Name = "earninglbl";
            earninglbl.Size = new Size(104, 38);
            earninglbl.TabIndex = 15;
            earninglbl.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            label4.BackColor = Color.Teal;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Image = (Image)resources.GetObject("label4.Image");
            label4.ImageAlign = ContentAlignment.TopRight;
            label4.Location = new Point(80, 104);
            label4.Name = "label4";
            label4.Padding = new Padding(5, 10, 0, 0);
            label4.Size = new Size(241, 142);
            label4.TabIndex = 17;
            label4.Text = "Products";
            // 
            // productslbl
            // 
            productslbl.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            productslbl.ForeColor = Color.Teal;
            productslbl.Location = new Point(94, 181);
            productslbl.Name = "productslbl";
            productslbl.Size = new Size(75, 38);
            productslbl.TabIndex = 18;
            productslbl.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(864, 765);
            ControlBox = false;
            Controls.Add(productslbl);
            Controls.Add(label4);
            Controls.Add(earninglbl);
            Controls.Add(label2);
            Controls.Add(totalproductlbl);
            Controls.Add(POS1);
            Controls.Add(label3);
            Controls.Add(qoutelbl);
            Controls.Add(datelbl);
            Controls.Add(timelbl);
            Controls.Add(newtaskbtn);
            Controls.Add(textBox1);
            Controls.Add(checkedListBox1);
            Controls.Add(label1);
            Controls.Add(timinglbl);
            Controls.Add(greetinglbl);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Dashboard";
            Text = "Dashboard";
            Load += Dashboard_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label greetinglbl;
        private Label timinglbl;
        private Label label1;
        private CheckedListBox checkedListBox1;
        private TextBox textBox1;
        private Button newtaskbtn;
        private Label timelbl;
        private Label datelbl;
        private System.Windows.Forms.Timer timer1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Label qoutelbl;
        private Label label3;
        private Label POS1;
        private Label totalproductlbl;
        private Label label2;
        private Label earninglbl;
        private Label label4;
        private Label productslbl;
    }
}