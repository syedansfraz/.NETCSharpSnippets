﻿namespace Super_Market_Management_Store
{
    partial class ChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChangePassword));
            submitbtn = new Button();
            btnsavebrandname = new Button();
            label2 = new Label();
            oldpasstb = new TextBox();
            label1 = new Label();
            newpasstb = new TextBox();
            label3 = new Label();
            confirmpasstb = new TextBox();
            SuspendLayout();
            // 
            // submitbtn
            // 
            submitbtn.BackColor = Color.Teal;
            submitbtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            submitbtn.ForeColor = Color.White;
            submitbtn.Location = new Point(48, 197);
            submitbtn.Name = "submitbtn";
            submitbtn.Size = new Size(266, 52);
            submitbtn.TabIndex = 7;
            submitbtn.Text = "Change";
            submitbtn.UseVisualStyleBackColor = false;
            submitbtn.Click += submitbtn_Click;
            // 
            // btnsavebrandname
            // 
            btnsavebrandname.BackColor = Color.Red;
            btnsavebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnsavebrandname.ForeColor = Color.White;
            btnsavebrandname.Location = new Point(320, 197);
            btnsavebrandname.Name = "btnsavebrandname";
            btnsavebrandname.Size = new Size(266, 52);
            btnsavebrandname.TabIndex = 8;
            btnsavebrandname.Text = "Cancel";
            btnsavebrandname.UseVisualStyleBackColor = false;
            btnsavebrandname.Click += btnsavebrandname_Click;
            // 
            // label2
            // 
            label2.Image = (Image)resources.GetObject("label2.Image");
            label2.Location = new Point(165, 39);
            label2.Name = "label2";
            label2.Size = new Size(26, 33);
            label2.TabIndex = 9;
            // 
            // oldpasstb
            // 
            oldpasstb.Location = new Point(200, 36);
            oldpasstb.Name = "oldpasstb";
            oldpasstb.PlaceholderText = "Old Password";
            oldpasstb.Size = new Size(266, 31);
            oldpasstb.TabIndex = 6;
            // 
            // label1
            // 
            label1.Image = (Image)resources.GetObject("label1.Image");
            label1.Location = new Point(165, 89);
            label1.Name = "label1";
            label1.Size = new Size(26, 33);
            label1.TabIndex = 11;
            // 
            // newpasstb
            // 
            newpasstb.Location = new Point(200, 86);
            newpasstb.Name = "newpasstb";
            newpasstb.PlaceholderText = "New Password";
            newpasstb.Size = new Size(266, 31);
            newpasstb.TabIndex = 10;
            newpasstb.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            label3.Image = (Image)resources.GetObject("label3.Image");
            label3.Location = new Point(165, 139);
            label3.Name = "label3";
            label3.Size = new Size(26, 33);
            label3.TabIndex = 13;
            // 
            // confirmpasstb
            // 
            confirmpasstb.Location = new Point(200, 136);
            confirmpasstb.Name = "confirmpasstb";
            confirmpasstb.PlaceholderText = "Confirm Password";
            confirmpasstb.Size = new Size(266, 31);
            confirmpasstb.TabIndex = 12;
            confirmpasstb.UseSystemPasswordChar = true;
            // 
            // ChangePassword
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(649, 278);
            Controls.Add(label3);
            Controls.Add(confirmpasstb);
            Controls.Add(label1);
            Controls.Add(newpasstb);
            Controls.Add(submitbtn);
            Controls.Add(btnsavebrandname);
            Controls.Add(label2);
            Controls.Add(oldpasstb);
            Name = "ChangePassword";
            Text = "ChangePassword";
            Load += ChangePassword_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button submitbtn;
        private Button btnsavebrandname;
        private Label label2;
        private TextBox oldpasstb;
        private Label label1;
        private TextBox newpasstb;
        private Label label3;
        private TextBox confirmpasstb;
    }
}