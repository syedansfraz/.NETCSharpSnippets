﻿namespace Super_Market_Management_Store
{
    partial class UpcomingShipments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            dataGridView1 = new DataGridView();
            id = new DataGridViewTextBoxColumn();
            description = new DataGridViewTextBoxColumn();
            Quantity = new DataGridViewTextBoxColumn();
            Brand = new DataGridViewTextBoxColumn();
            Category = new DataGridViewTextBoxColumn();
            Supplier = new DataGridViewTextBoxColumn();
            Price = new DataGridViewTextBoxColumn();
            ptb = new TextBox();
            label1 = new Label();
            qbox = new NumericUpDown();
            categorycombobox = new ComboBox();
            brandcombobox = new ComboBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            rntb = new TextBox();
            label3 = new Label();
            label2 = new Label();
            btnsavebrandname = new Button();
            datebox = new DateTimePicker();
            suppliercombobox = new ComboBox();
            label7 = new Label();
            btnremove = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)qbox).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Salmon;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = Color.Salmon;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { id, description, Quantity, Brand, Category, Supplier, Price });
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = Color.WhiteSmoke;
            dataGridView1.Location = new Point(1, 415);
            dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Teal;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = Color.Salmon;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(874, 280);
            dataGridView1.TabIndex = 8;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // id
            // 
            id.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            id.HeaderText = "Ref. #";
            id.MinimumWidth = 8;
            id.Name = "id";
            id.ReadOnly = true;
            id.Width = 93;
            // 
            // description
            // 
            description.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            description.HeaderText = "Product";
            description.MinimumWidth = 8;
            description.Name = "description";
            description.ReadOnly = true;
            // 
            // Quantity
            // 
            Quantity.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Quantity.HeaderText = "Quantity";
            Quantity.MinimumWidth = 8;
            Quantity.Name = "Quantity";
            Quantity.ReadOnly = true;
            Quantity.Width = 116;
            // 
            // Brand
            // 
            Brand.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Brand.HeaderText = "Brand";
            Brand.MinimumWidth = 8;
            Brand.Name = "Brand";
            Brand.ReadOnly = true;
            Brand.Width = 94;
            // 
            // Category
            // 
            Category.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Category.HeaderText = "Category";
            Category.MinimumWidth = 8;
            Category.Name = "Category";
            Category.ReadOnly = true;
            Category.Width = 120;
            // 
            // Supplier
            // 
            Supplier.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Supplier.HeaderText = "Supplier";
            Supplier.MinimumWidth = 8;
            Supplier.Name = "Supplier";
            Supplier.ReadOnly = true;
            Supplier.Width = 113;
            // 
            // Price
            // 
            Price.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Price.HeaderText = "Date";
            Price.MinimumWidth = 8;
            Price.Name = "Price";
            Price.ReadOnly = true;
            // 
            // ptb
            // 
            ptb.Location = new Point(262, 54);
            ptb.Name = "ptb";
            ptb.Size = new Size(199, 31);
            ptb.TabIndex = 26;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Salmon;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(97, 60);
            label1.Name = "label1";
            label1.Size = new Size(84, 25);
            label1.TabIndex = 38;
            label1.Text = "Product:";
            // 
            // qbox
            // 
            qbox.Location = new Point(629, 55);
            qbox.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            qbox.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            qbox.Name = "qbox";
            qbox.Size = new Size(147, 31);
            qbox.TabIndex = 30;
            qbox.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // categorycombobox
            // 
            categorycombobox.FormattingEnabled = true;
            categorycombobox.Location = new Point(262, 148);
            categorycombobox.Name = "categorycombobox";
            categorycombobox.Size = new Size(514, 33);
            categorycombobox.TabIndex = 28;
            // 
            // brandcombobox
            // 
            brandcombobox.FormattingEnabled = true;
            brandcombobox.Location = new Point(262, 100);
            brandcombobox.Name = "brandcombobox";
            brandcombobox.Size = new Size(514, 33);
            brandcombobox.TabIndex = 27;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Salmon;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(515, 60);
            label6.Name = "label6";
            label6.Size = new Size(92, 25);
            label6.TabIndex = 37;
            label6.Text = "Quantity:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Salmon;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(97, 106);
            label5.Name = "label5";
            label5.Size = new Size(68, 25);
            label5.TabIndex = 36;
            label5.Text = "Brand:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Salmon;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(97, 208);
            label4.Name = "label4";
            label4.Size = new Size(57, 25);
            label4.TabIndex = 35;
            label4.Text = "Date:";
            // 
            // rntb
            // 
            rntb.Location = new Point(262, 8);
            rntb.Name = "rntb";
            rntb.Size = new Size(514, 31);
            rntb.TabIndex = 25;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Salmon;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(97, 14);
            label3.Name = "label3";
            label3.Size = new Size(119, 25);
            label3.TabIndex = 34;
            label3.Text = "Reference #:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Salmon;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(97, 152);
            label2.Name = "label2";
            label2.Size = new Size(95, 25);
            label2.TabIndex = 33;
            label2.Text = "Category:";
            // 
            // btnsavebrandname
            // 
            btnsavebrandname.BackColor = Color.Salmon;
            btnsavebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnsavebrandname.ForeColor = Color.White;
            btnsavebrandname.Location = new Point(502, 335);
            btnsavebrandname.Name = "btnsavebrandname";
            btnsavebrandname.Size = new Size(134, 52);
            btnsavebrandname.TabIndex = 31;
            btnsavebrandname.Text = "Save";
            btnsavebrandname.UseVisualStyleBackColor = false;
            btnsavebrandname.Click += btnsavebrandname_Click;
            // 
            // datebox
            // 
            datebox.Location = new Point(262, 203);
            datebox.Name = "datebox";
            datebox.Size = new Size(317, 31);
            datebox.TabIndex = 39;
            // 
            // suppliercombobox
            // 
            suppliercombobox.FormattingEnabled = true;
            suppliercombobox.Location = new Point(262, 250);
            suppliercombobox.Name = "suppliercombobox";
            suppliercombobox.Size = new Size(514, 33);
            suppliercombobox.TabIndex = 40;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Salmon;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(97, 254);
            label7.Name = "label7";
            label7.Size = new Size(88, 25);
            label7.TabIndex = 41;
            label7.Text = "Supplier:";
            // 
            // btnremove
            // 
            btnremove.BackColor = Color.Salmon;
            btnremove.Dock = DockStyle.Bottom;
            btnremove.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnremove.ForeColor = Color.White;
            btnremove.Location = new Point(0, 699);
            btnremove.Name = "btnremove";
            btnremove.Size = new Size(873, 52);
            btnremove.TabIndex = 42;
            btnremove.Text = "Remove";
            btnremove.UseVisualStyleBackColor = false;
            btnremove.Click += btnremove_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Salmon;
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.White;
            button1.Location = new Point(642, 335);
            button1.Name = "button1";
            button1.Size = new Size(134, 52);
            button1.TabIndex = 43;
            button1.Text = "Refresh";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // UpcomingShipments
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(873, 751);
            Controls.Add(button1);
            Controls.Add(btnremove);
            Controls.Add(suppliercombobox);
            Controls.Add(label7);
            Controls.Add(datebox);
            Controls.Add(ptb);
            Controls.Add(label1);
            Controls.Add(qbox);
            Controls.Add(categorycombobox);
            Controls.Add(brandcombobox);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(rntb);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnsavebrandname);
            Controls.Add(dataGridView1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "UpcomingShipments";
            Text = "UpcomingShipments";
            Load += UpcomingShipments_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)qbox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private TextBox ptb;
        private Label label1;
        private NumericUpDown qbox;
        private ComboBox categorycombobox;
        private ComboBox brandcombobox;
        private Label label6;
        private Label label5;
        private Label label4;
        private TextBox rntb;
        private Label label3;
        private Label label2;
        private Button btnsavebrandname;
        private DateTimePicker datebox;
        private DataGridViewTextBoxColumn id;
        private DataGridViewTextBoxColumn description;
        private DataGridViewTextBoxColumn Quantity;
        private DataGridViewTextBoxColumn Brand;
        private DataGridViewTextBoxColumn Category;
        private DataGridViewTextBoxColumn Supplier;
        private DataGridViewTextBoxColumn Price;
        private ComboBox suppliercombobox;
        private Label label7;
        private Button btnremove;
        private Button button1;
    }
}