﻿using Super_Market_Management_Store.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Super_Market_Management_Store
{
    public partial class AllBrands : Form
    {
        public AllBrands()
        {
            InitializeComponent();

        }
        DatabaseConnection objConnect;
        string conString;
        DataSet ds;
        DataRow dRow;
        int MaxRows;
        int inc = 0;


        private void btnnewbrand_Click(object sender, EventArgs e)
        {
            //this.Dispose();
            brandModule brandModule = new brandModule();
            brandModule.ShowDialog();
        }
        public void loadbrand()
        {
            while (inc < MaxRows)
            {
                dRow = ds.Tables[0].Rows[inc];
                dataGridView1.Rows.Add(dRow.ItemArray);
                inc++;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void AllBrands_Load(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.SQL;
            ds = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
            loadbrand();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows.RemoveAt(rowIndex);
            ds.Tables[0].Rows[rowIndex].Delete();
            objConnect.UpdateDatabase(ds);
            MaxRows = ds.Tables[0].Rows.Count;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.SQL;
            ds = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
            loadbrand();

        }
    }
}
