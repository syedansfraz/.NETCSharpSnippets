﻿namespace Super_Market_Management_Store
{
    partial class DummyCart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label13 = new Label();
            proceedtocart = new Button();
            endshoppingcheckbox = new CheckBox();
            discountbox = new NumericUpDown();
            label12 = new Label();
            label11 = new Label();
            categorytb = new TextBox();
            brandtb = new TextBox();
            barcodetb = new TextBox();
            label5 = new Label();
            quantitybox = new NumericUpDown();
            label6 = new Label();
            label7 = new Label();
            pricebox = new TextBox();
            label8 = new Label();
            descriptiontb = new TextBox();
            label9 = new Label();
            label10 = new Label();
            ((System.ComponentModel.ISupportInitialize)discountbox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)quantitybox).BeginInit();
            SuspendLayout();
            // 
            // label13
            // 
            label13.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = Color.Salmon;
            label13.Location = new Point(483, 252);
            label13.Name = "label13";
            label13.Size = new Size(114, 37);
            label13.TabIndex = 155;
            label13.Text = "9%";
            label13.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // proceedtocart
            // 
            proceedtocart.FlatAppearance.BorderSize = 0;
            proceedtocart.FlatStyle = FlatStyle.Flat;
            proceedtocart.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            proceedtocart.ForeColor = Color.Salmon;
            proceedtocart.Location = new Point(195, 403);
            proceedtocart.Name = "proceedtocart";
            proceedtocart.Padding = new Padding(10, 0, 0, 0);
            proceedtocart.Size = new Size(424, 59);
            proceedtocart.TabIndex = 154;
            proceedtocart.Text = "Proceed to Cart";
            proceedtocart.UseVisualStyleBackColor = true;
            // 
            // endshoppingcheckbox
            // 
            endshoppingcheckbox.AutoSize = true;
            endshoppingcheckbox.Location = new Point(445, 320);
            endshoppingcheckbox.Name = "endshoppingcheckbox";
            endshoppingcheckbox.Size = new Size(209, 29);
            endshoppingcheckbox.TabIndex = 153;
            endshoppingcheckbox.Text = "My Shopping is done";
            endshoppingcheckbox.UseVisualStyleBackColor = true;
            // 
            // discountbox
            // 
            discountbox.Location = new Point(215, 252);
            discountbox.Name = "discountbox";
            discountbox.Size = new Size(180, 31);
            discountbox.TabIndex = 152;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Salmon;
            label12.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.White;
            label12.Location = new Point(410, 255);
            label12.Name = "label12";
            label12.Size = new Size(46, 25);
            label12.TabIndex = 151;
            label12.Text = "Tax:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Salmon;
            label11.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.White;
            label11.Location = new Point(86, 255);
            label11.Name = "label11";
            label11.Size = new Size(108, 25);
            label11.TabIndex = 150;
            label11.Text = "Discount%:";
            // 
            // categorytb
            // 
            categorytb.Location = new Point(251, 132);
            categorytb.Name = "categorytb";
            categorytb.Size = new Size(464, 31);
            categorytb.TabIndex = 149;
            // 
            // brandtb
            // 
            brandtb.Location = new Point(251, 83);
            brandtb.Name = "brandtb";
            brandtb.Size = new Size(464, 31);
            brandtb.TabIndex = 148;
            // 
            // barcodetb
            // 
            barcodetb.Location = new Point(251, 34);
            barcodetb.Name = "barcodetb";
            barcodetb.Size = new Size(464, 31);
            barcodetb.TabIndex = 139;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Salmon;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(86, 40);
            label5.Name = "label5";
            label5.Size = new Size(87, 25);
            label5.TabIndex = 147;
            label5.Text = "Barcode:";
            // 
            // quantitybox
            // 
            quantitybox.Location = new Point(568, 181);
            quantitybox.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            quantitybox.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            quantitybox.Name = "quantitybox";
            quantitybox.Size = new Size(147, 31);
            quantitybox.TabIndex = 141;
            quantitybox.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Salmon;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(456, 188);
            label6.Name = "label6";
            label6.Size = new Size(92, 25);
            label6.TabIndex = 146;
            label6.Text = "Quantity:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Salmon;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(86, 86);
            label7.Name = "label7";
            label7.Size = new Size(68, 25);
            label7.TabIndex = 145;
            label7.Text = "Brand:";
            // 
            // pricebox
            // 
            pricebox.Location = new Point(195, 185);
            pricebox.Name = "pricebox";
            pricebox.Size = new Size(181, 31);
            pricebox.TabIndex = 140;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Salmon;
            label8.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(86, 188);
            label8.Name = "label8";
            label8.Size = new Size(59, 25);
            label8.TabIndex = 144;
            label8.Text = "Price:";
            // 
            // descriptiontb
            // 
            descriptiontb.Location = new Point(251, -12);
            descriptiontb.Name = "descriptiontb";
            descriptiontb.Size = new Size(464, 31);
            descriptiontb.TabIndex = 138;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Salmon;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(86, -6);
            label9.Name = "label9";
            label9.Size = new Size(114, 25);
            label9.TabIndex = 143;
            label9.Text = "Description:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Salmon;
            label10.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.White;
            label10.Location = new Point(86, 132);
            label10.Name = "label10";
            label10.Size = new Size(95, 25);
            label10.TabIndex = 142;
            label10.Text = "Category:";
            // 
            // DummyCart
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label13);
            Controls.Add(proceedtocart);
            Controls.Add(endshoppingcheckbox);
            Controls.Add(discountbox);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(categorytb);
            Controls.Add(brandtb);
            Controls.Add(barcodetb);
            Controls.Add(label5);
            Controls.Add(quantitybox);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(pricebox);
            Controls.Add(label8);
            Controls.Add(descriptiontb);
            Controls.Add(label9);
            Controls.Add(label10);
            Name = "DummyCart";
            Text = "DummyCart";
            Load += DummyCart_Load;
            ((System.ComponentModel.ISupportInitialize)discountbox).EndInit();
            ((System.ComponentModel.ISupportInitialize)quantitybox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label13;
        private Button proceedtocart;
        private CheckBox endshoppingcheckbox;
        private NumericUpDown discountbox;
        public Label label12;
        public Label label11;
        public TextBox categorytb;
        public TextBox brandtb;
        public TextBox barcodetb;
        public Label label5;
        public NumericUpDown quantitybox;
        public Label label6;
        private Label label7;
        public TextBox pricebox;
        private Label label8;
        public TextBox descriptiontb;
        public Label label9;
        public Label label10;
    }
}