﻿namespace Super_Market_Management_Store
{
    partial class Cart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            dataGridView1 = new DataGridView();
            id = new DataGridViewTextBoxColumn();
            description = new DataGridViewTextBoxColumn();
            Brand = new DataGridViewTextBoxColumn();
            Category = new DataGridViewTextBoxColumn();
            Price = new DataGridViewTextBoxColumn();
            Quantity = new DataGridViewTextBoxColumn();
            Barcode = new DataGridViewTextBoxColumn();
            quantitybox = new NumericUpDown();
            label6 = new Label();
            discountbox = new NumericUpDown();
            label11 = new Label();
            label13 = new Label();
            label12 = new Label();
            totallbl = new Label();
            btnsavebrandname = new Button();
            idtextbox = new TextBox();
            label1 = new Label();
            submitbtn = new Button();
            label2 = new Label();
            button2 = new Button();
            label3 = new Label();
            totalamounttb = new Label();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)quantitybox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)discountbox).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Salmon;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = Color.Salmon;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { id, description, Brand, Category, Price, Quantity, Barcode });
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = Color.WhiteSmoke;
            dataGridView1.Location = new Point(3, 72);
            dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Teal;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = Color.Salmon;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(739, 199);
            dataGridView1.TabIndex = 9;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // id
            // 
            id.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            id.HeaderText = "ID";
            id.MinimumWidth = 8;
            id.Name = "id";
            id.ReadOnly = true;
            id.Width = 66;
            // 
            // description
            // 
            description.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            description.HeaderText = "Description";
            description.MinimumWidth = 8;
            description.Name = "description";
            description.ReadOnly = true;
            // 
            // Brand
            // 
            Brand.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Brand.HeaderText = "Brand";
            Brand.MinimumWidth = 8;
            Brand.Name = "Brand";
            Brand.ReadOnly = true;
            Brand.Width = 94;
            // 
            // Category
            // 
            Category.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Category.HeaderText = "Category";
            Category.MinimumWidth = 8;
            Category.Name = "Category";
            Category.ReadOnly = true;
            Category.Width = 120;
            // 
            // Price
            // 
            Price.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Price.HeaderText = "Price";
            Price.MinimumWidth = 8;
            Price.Name = "Price";
            Price.ReadOnly = true;
            Price.Width = 85;
            // 
            // Quantity
            // 
            Quantity.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Quantity.HeaderText = "Quantity";
            Quantity.MinimumWidth = 8;
            Quantity.Name = "Quantity";
            Quantity.ReadOnly = true;
            Quantity.Width = 116;
            // 
            // Barcode
            // 
            Barcode.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Barcode.HeaderText = "Barcode";
            Barcode.MinimumWidth = 8;
            Barcode.Name = "Barcode";
            Barcode.ReadOnly = true;
            Barcode.Width = 112;
            // 
            // quantitybox
            // 
            quantitybox.Location = new Point(448, 364);
            quantitybox.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            quantitybox.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            quantitybox.Name = "quantitybox";
            quantitybox.Size = new Size(178, 31);
            quantitybox.TabIndex = 156;
            quantitybox.Value = new decimal(new int[] { 1, 0, 0, 0 });
            quantitybox.ValueChanged += quantitybox_ValueChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Salmon;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(317, 366);
            label6.Name = "label6";
            label6.Size = new Size(92, 25);
            label6.TabIndex = 157;
            label6.Text = "Quantity:";
            label6.Click += label6_Click;
            // 
            // discountbox
            // 
            discountbox.Location = new Point(359, 421);
            discountbox.Name = "discountbox";
            discountbox.Size = new Size(178, 31);
            discountbox.TabIndex = 162;
            discountbox.ValueChanged += discountbox_ValueChanged;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Salmon;
            label11.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.White;
            label11.Location = new Point(228, 424);
            label11.Name = "label11";
            label11.Size = new Size(108, 25);
            label11.TabIndex = 161;
            label11.Text = "Discount%:";
            label11.Click += label11_Click;
            // 
            // label13
            // 
            label13.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = Color.Salmon;
            label13.Location = new Point(391, 455);
            label13.Name = "label13";
            label13.Size = new Size(114, 37);
            label13.TabIndex = 164;
            label13.Text = "7%";
            label13.TextAlign = ContentAlignment.MiddleCenter;
            label13.Click += label13_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Salmon;
            label12.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.White;
            label12.Location = new Point(226, 462);
            label12.Name = "label12";
            label12.Size = new Size(51, 25);
            label12.TabIndex = 163;
            label12.Text = "GST:";
            label12.Click += label12_Click;
            // 
            // totallbl
            // 
            totallbl.BackColor = Color.Salmon;
            totallbl.Dock = DockStyle.Top;
            totallbl.Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point);
            totallbl.ForeColor = SystemColors.ButtonHighlight;
            totallbl.ImageAlign = ContentAlignment.TopRight;
            totallbl.Location = new Point(0, 0);
            totallbl.Name = "totallbl";
            totallbl.Size = new Size(742, 74);
            totallbl.TabIndex = 165;
            totallbl.Text = "Cart";
            totallbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnsavebrandname
            // 
            btnsavebrandname.BackColor = Color.Red;
            btnsavebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnsavebrandname.ForeColor = Color.White;
            btnsavebrandname.Location = new Point(246, 277);
            btnsavebrandname.Name = "btnsavebrandname";
            btnsavebrandname.Size = new Size(266, 52);
            btnsavebrandname.TabIndex = 168;
            btnsavebrandname.Text = "Remove";
            btnsavebrandname.UseVisualStyleBackColor = false;
            btnsavebrandname.Click += btnsavebrandname_Click;
            // 
            // idtextbox
            // 
            idtextbox.Location = new Point(115, 364);
            idtextbox.Multiline = true;
            idtextbox.Name = "idtextbox";
            idtextbox.Size = new Size(176, 31);
            idtextbox.TabIndex = 169;
            // 
            // label1
            // 
            label1.BackColor = Color.Salmon;
            label1.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(15, 364);
            label1.Name = "label1";
            label1.Size = new Size(51, 30);
            label1.TabIndex = 170;
            label1.Text = "Id:";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // submitbtn
            // 
            submitbtn.BackColor = Color.Teal;
            submitbtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            submitbtn.ForeColor = Color.White;
            submitbtn.Location = new Point(219, 699);
            submitbtn.Name = "submitbtn";
            submitbtn.Size = new Size(318, 52);
            submitbtn.TabIndex = 171;
            submitbtn.Text = "Complete Transaction";
            submitbtn.UseVisualStyleBackColor = false;
            submitbtn.Click += submitbtn_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Salmon;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(219, 628);
            label2.Name = "label2";
            label2.Size = new Size(0, 25);
            label2.TabIndex = 174;
            // 
            // button2
            // 
            button2.BackColor = Color.Teal;
            button2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = SystemColors.ButtonHighlight;
            button2.Location = new Point(0, 516);
            button2.Name = "button2";
            button2.Size = new Size(742, 43);
            button2.TabIndex = 175;
            button2.Text = "Further Proceed";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Salmon;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(217, 637);
            label3.Name = "label3";
            label3.Size = new Size(133, 25);
            label3.TabIndex = 176;
            label3.Text = "Total Amount:";
            // 
            // totalamounttb
            // 
            totalamounttb.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            totalamounttb.ForeColor = Color.Salmon;
            totalamounttb.Location = new Point(371, 630);
            totalamounttb.Name = "totalamounttb";
            totalamounttb.Size = new Size(306, 36);
            totalamounttb.TabIndex = 177;
            totalamounttb.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // button1
            // 
            button1.BackColor = Color.Teal;
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.White;
            button1.Location = new Point(646, 352);
            button1.Name = "button1";
            button1.Size = new Size(73, 52);
            button1.TabIndex = 178;
            button1.Text = "Ok";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // Cart
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(742, 772);
            Controls.Add(button1);
            Controls.Add(totalamounttb);
            Controls.Add(label3);
            Controls.Add(button2);
            Controls.Add(label2);
            Controls.Add(submitbtn);
            Controls.Add(idtextbox);
            Controls.Add(label1);
            Controls.Add(btnsavebrandname);
            Controls.Add(totallbl);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(discountbox);
            Controls.Add(label11);
            Controls.Add(quantitybox);
            Controls.Add(label6);
            Controls.Add(dataGridView1);
            Name = "Cart";
            Text = "Cart";
            Load += Cart_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)quantitybox).EndInit();
            ((System.ComponentModel.ISupportInitialize)discountbox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn id;
        private DataGridViewTextBoxColumn description;
        private DataGridViewTextBoxColumn Brand;
        private DataGridViewTextBoxColumn Category;
        private DataGridViewTextBoxColumn Price;
        private DataGridViewTextBoxColumn Quantity;
        private DataGridViewTextBoxColumn Barcode;
        public NumericUpDown quantitybox;
        public Label label6;
        private NumericUpDown discountbox;
        public Label label11;
        private Label label13;
        public Label label12;
        private Label totallbl;
        private Button btnsavebrandname;
        private TextBox idtextbox;
        private Label label1;
        private Button submitbtn;
        public Label label2;
        private Button button2;
        public Label label3;
        private Label totalamounttb;
        private Button button1;
    }
}