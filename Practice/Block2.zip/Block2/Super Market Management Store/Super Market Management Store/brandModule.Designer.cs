﻿namespace Super_Market_Management_Store
{
    partial class brandModule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            brandnametxtbox = new TextBox();
            btnsavebrandname = new Button();
            btnclosebrandname = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Salmon;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(33, 53);
            label1.Name = "label1";
            label1.Size = new Size(123, 25);
            label1.TabIndex = 0;
            label1.Text = "Brand Name:";
            label1.Click += label1_Click;
            // 
            // brandnametxtbox
            // 
            brandnametxtbox.Location = new Point(173, 50);
            brandnametxtbox.Name = "brandnametxtbox";
            brandnametxtbox.Size = new Size(464, 31);
            brandnametxtbox.TabIndex = 1;
            brandnametxtbox.TextChanged += brandnametxtbox_TextChanged;
            // 
            // btnsavebrandname
            // 
            btnsavebrandname.BackColor = Color.Salmon;
            btnsavebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnsavebrandname.ForeColor = Color.White;
            btnsavebrandname.Location = new Point(319, 132);
            btnsavebrandname.Name = "btnsavebrandname";
            btnsavebrandname.Size = new Size(134, 52);
            btnsavebrandname.TabIndex = 2;
            btnsavebrandname.Text = "Save";
            btnsavebrandname.UseVisualStyleBackColor = false;
            btnsavebrandname.Click += btnsavebrandname_Click;
            // 
            // btnclosebrandname
            // 
            btnclosebrandname.BackColor = Color.Salmon;
            btnclosebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnclosebrandname.ForeColor = Color.White;
            btnclosebrandname.Location = new Point(490, 132);
            btnclosebrandname.Name = "btnclosebrandname";
            btnclosebrandname.Size = new Size(134, 52);
            btnclosebrandname.TabIndex = 3;
            btnclosebrandname.Text = "Close";
            btnclosebrandname.UseVisualStyleBackColor = false;
            btnclosebrandname.Click += btnclosebrandname_Click;
            // 
            // brandModule
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(673, 218);
            ControlBox = false;
            Controls.Add(btnclosebrandname);
            Controls.Add(btnsavebrandname);
            Controls.Add(brandnametxtbox);
            Controls.Add(label1);
            Name = "brandModule";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Add Brand";
            Load += brandModule_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox brandnametxtbox;
        private Button btnsavebrandname;
        private Button btnclosebrandname;
    }
}