﻿using Super_Market_Management_Store.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Super_Market_Management_Store
{
    public partial class UpcomingShipments : Form
    {
        public UpcomingShipments()
        {
            InitializeComponent();
        }
        DatabaseConnection objConnect;
        string conString;
        DataSet ds;
        DataSet ds2;
        DataSet ds3;
        DataSet ds4;
        DataRow dRow;
        DataRow dRow2;
        DataRow newRow;
        int MaxRows = 0;
        int inc = 0;

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnsavebrandname_Click(object sender, EventArgs e)
        {

            inc = 0;
            if (MessageBox.Show("Are you sure you want to add this brand?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                newRow = ds3.Tables[0].NewRow();
                newRow["Reference No"] = rntb.Text;
                newRow["Product"] = ptb.Text;
                newRow["Quantity"] = qbox.Value;// Assuming Brand is the column name
                newRow["Brand"] = brandcombobox.Text.ToString();// Assuming Category is the column name
                newRow["Category"] = categorycombobox.Text.ToString();
                newRow["Supplier"] = suppliercombobox.Text.ToString();
                newRow["Date"] = datebox.Value;
                ds3.Tables[0].Rows.Add(newRow);
                try
                {

                    objConnect.UpdateDatabase(ds3);
                    MaxRows = MaxRows + 1;
                    inc = MaxRows - 1;
                    MessageBox.Show("Database updated");
                }
                catch (Exception err)
                {

                    MessageBox.Show(err.Message);
                }

            }
        }

        private void UpcomingShipments_Load(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.SQL;
            ds = objConnect.GetConnection;
            objConnect.Sql = Properties.Settings.Default.SQL2;
            ds2 = objConnect.GetConnection;
            objConnect.Sql = Properties.Settings.Default.Supplier;
            ds4 = objConnect.GetConnection;
            objConnect.Sql = Properties.Settings.Default.upcomingstock;
            ds3 = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
            loadbrandincombobox();
            loadcategoryincombobox();
            loadsupplierincombobox();
            loadproduct();
        }
        public void loadproduct()
        {
            dataGridView1.Rows.Clear();
            inc = 0;
            MaxRows = ds3.Tables[0].Rows.Count;
            while (inc < MaxRows)
            {
                dRow = ds3.Tables[0].Rows[inc];
                dataGridView1.Rows.Add(dRow.ItemArray);
                inc++;
            }
        }
        private void loadsupplierincombobox()
        {
            inc = 0;
            {
                // Assuming ds2 is the DataSet for the second database
                DataTable table2 = ds4.Tables[0];

                for (int i = 0; i < table2.Rows.Count; i++)
                {
                    DataRow row = table2.Rows[i];
                    suppliercombobox.Items.Add(row["Supplier"].ToString());
                }
            }
        }
        private void loadbrandincombobox()
        {
            inc = 0;
            {
                // Assuming ds2 is the DataSet for the second database
                DataTable table2 = ds.Tables[0];

                for (int i = 0; i < table2.Rows.Count; i++)
                {
                    DataRow row = table2.Rows[i];
                    brandcombobox.Items.Add(row["Brand"].ToString());
                }
            }

        }
        public void loadcategoryincombobox()
        {
            inc = 0;
            {
                // Assuming ds2 is the DataSet for the second database
                DataTable table2 = ds2.Tables[0];

                for (int i = 0; i < table2.Rows.Count; i++)
                {
                    DataRow row = table2.Rows[i];
                    categorycombobox.Items.Add(row["Category"].ToString());
                }
            }
        }

        private void btnclosebrandname_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnremove_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows.RemoveAt(rowIndex);
            ds3.Tables[0].Rows[rowIndex].Delete();
            objConnect.UpdateDatabase(ds3);
            MaxRows = ds3.Tables[0].Rows.Count;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.upcomingstock;
            ds3 = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
            loadproduct();

        }
    }
}
