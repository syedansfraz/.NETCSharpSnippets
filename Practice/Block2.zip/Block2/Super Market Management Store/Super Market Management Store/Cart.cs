﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Super_Market_Management_Store
{

    public partial class Cart : Form
    {
        public Cart()
        {
            InitializeComponent();
        }
        DataRow dRow;
        int inc = 0;
        DatabaseConnection objConnect;
        string conString;
        DataSet ds;
        //      DataRow dRow;
        int MaxRows;
        int rowindexx;
        //        int inc = 0;

        private void Cart_Load(object sender, EventArgs e)
        {
            string constr = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM DummyCart", con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet dataTable = new DataSet();
            adapter.Fill(dataTable);
            int maxrow = dataTable.Tables[0].Rows.Count;

            if (dataTable.Tables[0].Rows.Count != 0)
            {
                while (inc < maxrow)
                {
                    dRow = dataTable.Tables[0].Rows[inc];
                    dataGridView1.Rows.Add(dRow.ItemArray);
                    inc++;
                }
            }
            else
            {


            }
            con.Close();


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            rowindexx = e.RowIndex;
        }

        private void quantitybox_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {
        }

        private void label12_Click(object sender, EventArgs e)
        {
        }

        private void discountbox_ValueChanged(object sender, EventArgs e)
        {
        }

        private void label11_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string conStr = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string query = "UPDATE DummyCart SET Quantity = @newquantity WHERE Id=@productid";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@newquantity", quantitybox.Value);
            cmd.Parameters.AddWithValue("@productid", idtextbox.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Quantity Updated");

        }

        private void label6_Click(object sender, EventArgs e)
        {
        }
        public void loadproduct()
        {
            inc = 0;
            while (inc < MaxRows)
            {
                dRow = ds.Tables[0].Rows[inc];
                dataGridView1.Rows.Add(dRow.ItemArray);
                inc++;
            }
        }

        private void btnsavebrandname_Click(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.removefromcart;
            ds = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
            int rowIndex = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows.RemoveAt(rowIndex);
            ds.Tables[0].Rows[rowIndex].Delete();
            objConnect.UpdateDatabase(ds);
            MaxRows = ds.Tables[0].Rows.Count;

            button2.PerformClick();
        }

        private void submitbtn_Click(object sender, EventArgs e)
        {
            quantityupdation();
            string conStr = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string query = "INSERT INTO salesrecord (Description, Brand, Category, Price, Quantity, Barcode, Discount, Total) SELECT Description, Brand, Category, Price, Quantity, Barcode, @Discount AS Discount,((Price*Quantity)-((Price*Quantity)*(@Discount/100)))*(1+0.07) AS Total FROM DummyCart;";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Discount", discountbox.Value);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Entered in Sales Record");
            SqlConnection con2 = new SqlConnection(conStr);
            con2.Open();
            string query2 = "DELETE From DummyCart;";
            SqlCommand cmd2 = new SqlCommand(query2, con2);
            cmd2.ExecuteNonQuery();
            con2.Close();
            this.Close();

            string conStr12 = Properties.Settings.Default.EmployeesConnectionString;
            using (SqlConnection con12 = new SqlConnection(conStr12))
            {
                con12.Open();

                string query12 = "UPDATE Nameofproduct SET Nameofproduct.Quantity = Nameofproduct.Quantity - DummyCart.Quantity FROM Nameofproduct JOIN DummyCart ON Nameofproduct.Id = DummyCart.Id";
                using (SqlCommand cmd12 = new SqlCommand(query12, con12))
                {
                    cmd12.ExecuteNonQuery();
                }

                con12.Close();

            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            string conStr2 = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con2 = new SqlConnection(conStr2);
            con2.Open();
            string query2 = "UPDATE DummyCart SET Totalcart= Totalcart*Quantity";
            SqlCommand cmd2 = new SqlCommand(query2, con2);
            cmd2.Parameters.AddWithValue("@newquantity", quantitybox.Value);
            cmd2.Parameters.AddWithValue("@productid", idtextbox.Text);
            cmd2.ExecuteNonQuery();
            con2.Close();


            string conStr23 = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con23 = new SqlConnection(conStr2);
            con23.Open();
            string query23 = "UPDATE DummyCart SET Discount = @newquantity, Totalcart = ((Totalcart)-(Totalcart *(@newquantity/100)))*(1+0.07)";
            SqlCommand cmd23 = new SqlCommand(query23, con23);
            cmd23.Parameters.AddWithValue("@newquantity", discountbox.Value);
            cmd23.ExecuteNonQuery();
            con23.Close();
            MessageBox.Show("Quantity and Discount performed");


            string conStr = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string query = "SELECT SUM(Totalcart) FROM DummyCart;";
            SqlCommand cmd = new SqlCommand(query, con);
            object result = cmd.ExecuteScalar();

            // Check if the result is not null before converting to a string
            if (result != null)
            {
                string sumTotal = result.ToString();

                // Assuming you have a label named 'label1' on your form
                totalamounttb.Text = "" + sumTotal;
                MessageBox.Show(sumTotal);
            }
            else
            {
                totalamounttb.Text = "No data found"; // Or handle the case when there is no data
            }

            con.Close();
        }
        public void quantityupdation()
        {
            try { 
            string conStr = Properties.Settings.Default.EmployeesConnectionString;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string query = "UPDATE Nameofproduct SET Nameofproduct.Quantity = Nameofproduct.Quantity - DummyCart.Quantity FROM Nameofproduct JOIN DummyCart ON Nameofproduct.Id = DummyCart.Id";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.ExecuteNonQuery();
                }

                con.Close();
            }
            }
            catch { 

            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //quantityupdation();
            try
            {
            string conStr2 = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con2 = new SqlConnection(conStr2);
            con2.Open();
            string query2 = "UPDATE DummyCart SET Quantity= @newquantity WHERE Id=@productid AND @newquantity <= (SELECT Quantity FROM Nameofproduct WHERE Id = @productid)";
            SqlCommand cmd2 = new SqlCommand(query2, con2);
            cmd2.Parameters.AddWithValue("@newquantity", quantitybox.Value);
            cmd2.Parameters.AddWithValue("@productid", idtextbox.Text);

                int rowsAffected = cmd2.ExecuteNonQuery();
               if (rowsAffected > 0)
                {
                    // The update was successful
                    MessageBox.Show("Quantity updated");
                }
                else
                {
                    // No rows were affected, indicating the condition was not met
                    MessageBox.Show("Inventory doesnot contain that much quantity");
                }
                con2.Close();
            string constr12 = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con12 = new SqlConnection(constr12);
            con12.Open();
            SqlCommand cmd12 = new SqlCommand("SELECT * FROM DummyCart", con12);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd12);
            DataSet dataTable = new DataSet();
            adapter.Fill(dataTable);
            int maxrow = dataTable.Tables[0].Rows.Count;

            if (dataTable.Tables[0].Rows.Count != 0)
            {
                inc = 0;
                dataGridView1.Rows.Clear();
                while (inc < maxrow)
                {
                    dRow = dataTable.Tables[0].Rows[inc];
                    dataGridView1.Rows.Add(dRow.ItemArray);
                    inc++;
                }
            }
            else
            {


            }
            con12.Close();
            }
            catch (Exception)
            {

                throw;
            }
        }

        
    }
}
