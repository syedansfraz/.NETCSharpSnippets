﻿using Super_Market_Management_Store.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Super_Market_Management_Store
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        SqlDataReader dr;
        bool found = false;
        string role;
        bool active;
        string passwordd;
        private void login_Load(object sender, EventArgs e)
        {

        }

        private void submitbtn_Click(object sender, EventArgs e)
        {

        }

        private void submitbtn_Click_1(object sender, EventArgs e)
        {
            try
            {
                string conStr = Properties.Settings.Default.EmployeesConnectionString;
                SqlConnection con = new SqlConnection(conStr);
                con.Open();
                string query = "SELECT * FROM users WHERE username = @username AND password = @password";
                SqlCommand cmd = new SqlCommand(query, con);

                // Add parameters
                cmd.Parameters.AddWithValue("@username", nametb.Text);
                cmd.Parameters.AddWithValue("@password", passwrdtb.Text);

                dr = cmd.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    found = true;
                    role = dr["role"].ToString();
                    active = bool.Parse(dr["isactive"].ToString());
                    passwordd = dr["password"].ToString();
                    
                }
                else
                {
                    found = false;
                    MessageBox.Show("Invalid Name or Password");
                }
                con.Close();
                dr.Close();
                if(found)
                { 
                    if(!active)
                    {
                        MessageBox.Show("Account INACTIVE!", "ACCESS DENIED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                       if(role=="Cashier")
                    {
                        MessageBox.Show("Welcome!", "ACCESS GRANTED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        Cashier cashier = new Cashier();
                        cashier.ShowDialog();
                    }
                       if(role=="Admin")
                    {
                        MessageBox.Show("Welcome!", "ACCESS GRANTED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        mainForm mainForm = new mainForm();
                        mainForm.ShowDialog();
                    }
                }
            }
            catch (Exception  ex)
            {
                MessageBox.Show(ex.Message);

                throw;
            }
        }

        private void btnsavebrandname_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Exit?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Environment.Exit(0);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
    
}
