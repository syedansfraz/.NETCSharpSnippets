﻿namespace Super_Market_Management_Store
{
    partial class CategoryModule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnclosebrandname = new Button();
            btnsavebrandname = new Button();
            brandnametxtbox = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnclosebrandname
            // 
            btnclosebrandname.BackColor = Color.Salmon;
            btnclosebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnclosebrandname.ForeColor = Color.White;
            btnclosebrandname.Location = new Point(491, 124);
            btnclosebrandname.Name = "btnclosebrandname";
            btnclosebrandname.Size = new Size(134, 52);
            btnclosebrandname.TabIndex = 7;
            btnclosebrandname.Text = "Close";
            btnclosebrandname.UseVisualStyleBackColor = false;
            btnclosebrandname.Click += btnclosebrandname_Click;
            // 
            // btnsavebrandname
            // 
            btnsavebrandname.BackColor = Color.Salmon;
            btnsavebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnsavebrandname.ForeColor = Color.White;
            btnsavebrandname.Location = new Point(320, 124);
            btnsavebrandname.Name = "btnsavebrandname";
            btnsavebrandname.Size = new Size(134, 52);
            btnsavebrandname.TabIndex = 6;
            btnsavebrandname.Text = "Save";
            btnsavebrandname.UseVisualStyleBackColor = false;
            btnsavebrandname.Click += btnsavebrandname_Click;
            // 
            // brandnametxtbox
            // 
            brandnametxtbox.Location = new Point(174, 42);
            brandnametxtbox.Name = "brandnametxtbox";
            brandnametxtbox.Size = new Size(464, 31);
            brandnametxtbox.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Salmon;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(12, 45);
            label1.Name = "label1";
            label1.Size = new Size(150, 25);
            label1.TabIndex = 4;
            label1.Text = "Category Name:";
            // 
            // CategoryModule
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(673, 218);
            ControlBox = false;
            Controls.Add(btnclosebrandname);
            Controls.Add(btnsavebrandname);
            Controls.Add(brandnametxtbox);
            Controls.Add(label1);
            Name = "CategoryModule";
            Text = "Category Module";
            Load += CategoryModule_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnclosebrandname;
        private Button btnsavebrandname;
        private TextBox brandnametxtbox;
        private Label label1;
    }
}