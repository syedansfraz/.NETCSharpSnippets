﻿namespace WinFormsApp2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            newToolStripMenuItem = new ToolStripMenuItem();
            ansToolStripMenuItem = new ToolStripMenuItem();
            shahToolStripMenuItem = new ToolStripMenuItem();
            cancelToolStripMenuItem = new ToolStripMenuItem();
            sunnyToolStripMenuItem = new ToolStripMenuItem();
            buttToolStripMenuItem = new ToolStripMenuItem();
            openToolStripMenuItem = new ToolStripMenuItem();
            recentFilesToolStripMenuItem = new ToolStripMenuItem();
            quickToolStripMenuItem = new ToolStripMenuItem();
            quitToolStripMenuItem = new ToolStripMenuItem();
            whoIsBondaToolStripMenuItem = new ToolStripMenuItem();
            editToolStripMenuItem = new ToolStripMenuItem();
            toolstripToolStripMenuItem = new ToolStripMenuItem();
            timerToolStripMenuItem = new ToolStripMenuItem();
            splitterToolStripMenuItem = new ToolStripMenuItem();
            viewToolStripMenuItem = new ToolStripMenuItem();
            treeViewToolStripMenuItem = new ToolStripMenuItem();
            statusStripToolStripMenuItem = new ToolStripMenuItem();
            splitContainerToolStripMenuItem = new ToolStripMenuItem();
            gitToolStripMenuItem = new ToolStripMenuItem();
            cloneRepositoryToolStripMenuItem = new ToolStripMenuItem();
            formatToolStripMenuItem = new ToolStripMenuItem();
            alignToolStripMenuItem = new ToolStripMenuItem();
            makeSameSizeToolStripMenuItem = new ToolStripMenuItem();
            testToolStripMenuItem = new ToolStripMenuItem();
            configureRunSettingToolStripMenuItem = new ToolStripMenuItem();
            analyzeToolStripMenuItem = new ToolStripMenuItem();
            codeCleanUpToolStripMenuItem = new ToolStripMenuItem();
            toolsToolStripMenuItem = new ToolStripMenuItem();
            androidToolStripMenuItem = new ToolStripMenuItem();
            iOSToolStripMenuItem = new ToolStripMenuItem();
            themeToolStripMenuItem = new ToolStripMenuItem();
            extensionsToolStripMenuItem = new ToolStripMenuItem();
            manageExtensionsToolStripMenuItem = new ToolStripMenuItem();
            customizeMenuToolStripMenuItem = new ToolStripMenuItem();
            textBox1 = new TextBox();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, editToolStripMenuItem, viewToolStripMenuItem, gitToolStripMenuItem, formatToolStripMenuItem, testToolStripMenuItem, analyzeToolStripMenuItem, toolsToolStripMenuItem, extensionsToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 33);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { newToolStripMenuItem, cancelToolStripMenuItem, openToolStripMenuItem, recentFilesToolStripMenuItem, quickToolStripMenuItem, quitToolStripMenuItem, whoIsBondaToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.Q;
            fileToolStripMenuItem.Size = new Size(54, 29);
            fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            newToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ansToolStripMenuItem, shahToolStripMenuItem });
            newToolStripMenuItem.Name = "newToolStripMenuItem";
            newToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.N;
            newToolStripMenuItem.Size = new Size(323, 34);
            newToolStripMenuItem.Text = "New";
            // 
            // ansToolStripMenuItem
            // 
            ansToolStripMenuItem.Name = "ansToolStripMenuItem";
            ansToolStripMenuItem.Size = new Size(153, 34);
            ansToolStripMenuItem.Text = "Ans";
            // 
            // shahToolStripMenuItem
            // 
            shahToolStripMenuItem.Name = "shahToolStripMenuItem";
            shahToolStripMenuItem.Size = new Size(153, 34);
            shahToolStripMenuItem.Text = "Shah";
            // 
            // cancelToolStripMenuItem
            // 
            cancelToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { sunnyToolStripMenuItem, buttToolStripMenuItem });
            cancelToolStripMenuItem.Name = "cancelToolStripMenuItem";
            cancelToolStripMenuItem.Size = new Size(323, 34);
            cancelToolStripMenuItem.Text = "Cancel";
            // 
            // sunnyToolStripMenuItem
            // 
            sunnyToolStripMenuItem.Name = "sunnyToolStripMenuItem";
            sunnyToolStripMenuItem.Size = new Size(163, 34);
            sunnyToolStripMenuItem.Text = "Sunny";
            // 
            // buttToolStripMenuItem
            // 
            buttToolStripMenuItem.Name = "buttToolStripMenuItem";
            buttToolStripMenuItem.Size = new Size(163, 34);
            buttToolStripMenuItem.Text = "Butt";
            // 
            // openToolStripMenuItem
            // 
            openToolStripMenuItem.Name = "openToolStripMenuItem";
            openToolStripMenuItem.Size = new Size(323, 34);
            openToolStripMenuItem.Text = "Open";
            // 
            // recentFilesToolStripMenuItem
            // 
            recentFilesToolStripMenuItem.Name = "recentFilesToolStripMenuItem";
            recentFilesToolStripMenuItem.Size = new Size(323, 34);
            recentFilesToolStripMenuItem.Text = "Recent files";
            // 
            // quickToolStripMenuItem
            // 
            quickToolStripMenuItem.Name = "quickToolStripMenuItem";
            quickToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.Q;
            quickToolStripMenuItem.Size = new Size(323, 34);
            quickToolStripMenuItem.Text = "Quick";
            quickToolStripMenuItem.Click += quickToolStripMenuItem_Click;
            // 
            // quitToolStripMenuItem
            // 
            quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            quitToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.E;
            quitToolStripMenuItem.Size = new Size(323, 34);
            quitToolStripMenuItem.Text = "Quit";
            quitToolStripMenuItem.Click += quitToolStripMenuItem_Click;
            // 
            // whoIsBondaToolStripMenuItem
            // 
            whoIsBondaToolStripMenuItem.Name = "whoIsBondaToolStripMenuItem";
            whoIsBondaToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.B;
            whoIsBondaToolStripMenuItem.Size = new Size(323, 34);
            whoIsBondaToolStripMenuItem.Text = "Who is GoodMan?";
            whoIsBondaToolStripMenuItem.Click += whoIsBondaToolStripMenuItem_Click;
            // 
            // editToolStripMenuItem
            // 
            editToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { toolstripToolStripMenuItem, timerToolStripMenuItem, splitterToolStripMenuItem });
            editToolStripMenuItem.Name = "editToolStripMenuItem";
            editToolStripMenuItem.Size = new Size(58, 29);
            editToolStripMenuItem.Text = "Edit";
            // 
            // toolstripToolStripMenuItem
            // 
            toolstripToolStripMenuItem.Name = "toolstripToolStripMenuItem";
            toolstripToolStripMenuItem.Size = new Size(182, 34);
            toolstripToolStripMenuItem.Text = "Toolstrip";
            // 
            // timerToolStripMenuItem
            // 
            timerToolStripMenuItem.Name = "timerToolStripMenuItem";
            timerToolStripMenuItem.Size = new Size(182, 34);
            timerToolStripMenuItem.Text = "Timer";
            // 
            // splitterToolStripMenuItem
            // 
            splitterToolStripMenuItem.Name = "splitterToolStripMenuItem";
            splitterToolStripMenuItem.Size = new Size(182, 34);
            splitterToolStripMenuItem.Text = "Splitter";
            // 
            // viewToolStripMenuItem
            // 
            viewToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { treeViewToolStripMenuItem, statusStripToolStripMenuItem, splitContainerToolStripMenuItem });
            viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            viewToolStripMenuItem.Size = new Size(65, 29);
            viewToolStripMenuItem.Text = "View";
            // 
            // treeViewToolStripMenuItem
            // 
            treeViewToolStripMenuItem.Name = "treeViewToolStripMenuItem";
            treeViewToolStripMenuItem.Size = new Size(225, 34);
            treeViewToolStripMenuItem.Text = "TreeView";
            // 
            // statusStripToolStripMenuItem
            // 
            statusStripToolStripMenuItem.Name = "statusStripToolStripMenuItem";
            statusStripToolStripMenuItem.Size = new Size(225, 34);
            statusStripToolStripMenuItem.Text = "StatusStrip";
            // 
            // splitContainerToolStripMenuItem
            // 
            splitContainerToolStripMenuItem.Name = "splitContainerToolStripMenuItem";
            splitContainerToolStripMenuItem.Size = new Size(225, 34);
            splitContainerToolStripMenuItem.Text = "SplitContainer";
            // 
            // gitToolStripMenuItem
            // 
            gitToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cloneRepositoryToolStripMenuItem });
            gitToolStripMenuItem.Name = "gitToolStripMenuItem";
            gitToolStripMenuItem.Size = new Size(50, 29);
            gitToolStripMenuItem.Text = "Git";
            // 
            // cloneRepositoryToolStripMenuItem
            // 
            cloneRepositoryToolStripMenuItem.Name = "cloneRepositoryToolStripMenuItem";
            cloneRepositoryToolStripMenuItem.Size = new Size(249, 34);
            cloneRepositoryToolStripMenuItem.Text = "Clone Repository";
            // 
            // formatToolStripMenuItem
            // 
            formatToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { alignToolStripMenuItem, makeSameSizeToolStripMenuItem });
            formatToolStripMenuItem.Name = "formatToolStripMenuItem";
            formatToolStripMenuItem.Size = new Size(85, 29);
            formatToolStripMenuItem.Text = "Format";
            // 
            // alignToolStripMenuItem
            // 
            alignToolStripMenuItem.Name = "alignToolStripMenuItem";
            alignToolStripMenuItem.Size = new Size(238, 34);
            alignToolStripMenuItem.Text = "Align";
            // 
            // makeSameSizeToolStripMenuItem
            // 
            makeSameSizeToolStripMenuItem.Name = "makeSameSizeToolStripMenuItem";
            makeSameSizeToolStripMenuItem.Size = new Size(238, 34);
            makeSameSizeToolStripMenuItem.Text = "Make same size";
            // 
            // testToolStripMenuItem
            // 
            testToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { configureRunSettingToolStripMenuItem });
            testToolStripMenuItem.Name = "testToolStripMenuItem";
            testToolStripMenuItem.Size = new Size(58, 29);
            testToolStripMenuItem.Text = "Test";
            // 
            // configureRunSettingToolStripMenuItem
            // 
            configureRunSettingToolStripMenuItem.Name = "configureRunSettingToolStripMenuItem";
            configureRunSettingToolStripMenuItem.Size = new Size(282, 34);
            configureRunSettingToolStripMenuItem.Text = "Configure run setting";
            // 
            // analyzeToolStripMenuItem
            // 
            analyzeToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { codeCleanUpToolStripMenuItem });
            analyzeToolStripMenuItem.Name = "analyzeToolStripMenuItem";
            analyzeToolStripMenuItem.Size = new Size(89, 29);
            analyzeToolStripMenuItem.Text = "Analyze";
            // 
            // codeCleanUpToolStripMenuItem
            // 
            codeCleanUpToolStripMenuItem.Name = "codeCleanUpToolStripMenuItem";
            codeCleanUpToolStripMenuItem.Size = new Size(227, 34);
            codeCleanUpToolStripMenuItem.Text = "Code CleanUp";
            // 
            // toolsToolStripMenuItem
            // 
            toolsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { androidToolStripMenuItem, iOSToolStripMenuItem, themeToolStripMenuItem });
            toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            toolsToolStripMenuItem.Size = new Size(69, 29);
            toolsToolStripMenuItem.Text = "Tools";
            // 
            // androidToolStripMenuItem
            // 
            androidToolStripMenuItem.Name = "androidToolStripMenuItem";
            androidToolStripMenuItem.Size = new Size(179, 34);
            androidToolStripMenuItem.Text = "Android";
            // 
            // iOSToolStripMenuItem
            // 
            iOSToolStripMenuItem.Name = "iOSToolStripMenuItem";
            iOSToolStripMenuItem.Size = new Size(179, 34);
            iOSToolStripMenuItem.Text = "IOS";
            // 
            // themeToolStripMenuItem
            // 
            themeToolStripMenuItem.Name = "themeToolStripMenuItem";
            themeToolStripMenuItem.Size = new Size(179, 34);
            themeToolStripMenuItem.Text = "Theme";
            // 
            // extensionsToolStripMenuItem
            // 
            extensionsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { manageExtensionsToolStripMenuItem, customizeMenuToolStripMenuItem });
            extensionsToolStripMenuItem.Name = "extensionsToolStripMenuItem";
            extensionsToolStripMenuItem.Size = new Size(111, 29);
            extensionsToolStripMenuItem.Text = "Extensions";
            // 
            // manageExtensionsToolStripMenuItem
            // 
            manageExtensionsToolStripMenuItem.Name = "manageExtensionsToolStripMenuItem";
            manageExtensionsToolStripMenuItem.Size = new Size(266, 34);
            manageExtensionsToolStripMenuItem.Text = "Manage Extensions";
            // 
            // customizeMenuToolStripMenuItem
            // 
            customizeMenuToolStripMenuItem.Name = "customizeMenuToolStripMenuItem";
            customizeMenuToolStripMenuItem.Size = new Size(266, 34);
            customizeMenuToolStripMenuItem.Text = "Customize Menu";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(233, 186);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(344, 31);
            textBox1.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem newToolStripMenuItem;
        private ToolStripMenuItem ansToolStripMenuItem;
        private ToolStripMenuItem shahToolStripMenuItem;
        private ToolStripMenuItem cancelToolStripMenuItem;
        private ToolStripMenuItem openToolStripMenuItem;
        private ToolStripMenuItem recentFilesToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem toolstripToolStripMenuItem;
        private ToolStripMenuItem timerToolStripMenuItem;
        private ToolStripMenuItem splitterToolStripMenuItem;
        private ToolStripMenuItem viewToolStripMenuItem;
        private ToolStripMenuItem treeViewToolStripMenuItem;
        private ToolStripMenuItem statusStripToolStripMenuItem;
        private ToolStripMenuItem splitContainerToolStripMenuItem;
        private ToolStripMenuItem gitToolStripMenuItem;
        private ToolStripMenuItem cloneRepositoryToolStripMenuItem;
        private ToolStripMenuItem formatToolStripMenuItem;
        private ToolStripMenuItem alignToolStripMenuItem;
        private ToolStripMenuItem makeSameSizeToolStripMenuItem;
        private ToolStripMenuItem testToolStripMenuItem;
        private ToolStripMenuItem analyzeToolStripMenuItem;
        private ToolStripMenuItem toolsToolStripMenuItem;
        private ToolStripMenuItem extensionsToolStripMenuItem;
        private ToolStripMenuItem configureRunSettingToolStripMenuItem;
        private ToolStripMenuItem codeCleanUpToolStripMenuItem;
        private ToolStripMenuItem androidToolStripMenuItem;
        private ToolStripMenuItem iOSToolStripMenuItem;
        private ToolStripMenuItem themeToolStripMenuItem;
        private ToolStripMenuItem manageExtensionsToolStripMenuItem;
        private ToolStripMenuItem customizeMenuToolStripMenuItem;
        private ToolStripMenuItem sunnyToolStripMenuItem;
        private ToolStripMenuItem buttToolStripMenuItem;
        private ToolStripMenuItem quickToolStripMenuItem;
        private ToolStripMenuItem quitToolStripMenuItem;
        private ToolStripMenuItem whoIsBondaToolStripMenuItem;
        private TextBox textBox1;
    }
}