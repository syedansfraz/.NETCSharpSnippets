﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MidTermTask
{

    public struct Product
    {
        public double Price
        {
            get; set;
        }
        public int id { get; set; }
        public int stock  { get; set; } 
        public string Name{ get; set; }
        //without these sets and gets we cannot update and get values
        public Product(int pid, string name, double price, int Stock) //Constructor
        {
            id = pid;
            Name = name;
            Price = price;
            stock = Stock;
        }

        public void updateItems(int sale)
        {
            if (sale <= stock )
            {
                stock = stock - sale;
                Console.WriteLine("Updated");
            }
            else
            {
                Console.WriteLine("There is no "+Name+".");
            }
        }
    }

    public class store
    {
        private List<Product> products; // private banaya hai, koi directly access na kr sake.
        public store()
        {
            products = new List<Product>();
        }
        

        public void AddProduct(Product product)
        {
            products.Add(product);
            Console.WriteLine("Product "+product.Name+" added to the inventory.");
        }

        public void UpdateProduct(int proId, Product updatePro)
        {
            // Product ko list main sy dondhne k lia
            int index = -1;
            for (int i = 0; i < products.Count; i++)
            {
                if (products[i].id == proId)
                {
                    index = i;
                    break;
                }
            }

            if (index != -1)
            {
                products[index] = updatePro;
                Console.WriteLine("Product "+ updatePro.Name+" updated successfully.");
            }
            else
            {
                Console.WriteLine($"Product with ID "+proId+" not found.");
            }
        }

        public void displayInv()
        {
            Console.WriteLine("Current Inventory:");
            foreach (var item in products)
            {
              Console.WriteLine("ID: "+item.id+", Name: "+ item.Name+" Price: "+ item.Price +", Quantity: "+ item.stock);
            }
        }

        public void UpdateStock(int proId, int sold)
        {
            // Product ko list main sy dondhne k lia
            int index = -1;
            for (int i = 0; i < products.Count; i++)
            {
                if (products[i].id == proId)
                {
                    index = i;
                    break;
                }
            }

            if (index != -1)
            {
                products[index].updateItems(sold);
            }
            else
            {
                Console.WriteLine("Product with ID "+proId+" not found.");
            }
        }
    }

    class Program
    {
   
            static void Main()
            {
            store manageStore = new store();
            Console.WriteLine("----------- Inventory Management System -----------");
                do
                {
                    Console.WriteLine("What do you want to perform:");
                    Console.WriteLine("1. Add Product");
                    Console.WriteLine("2. Update Product");
                    Console.WriteLine("3. Update Stock");
                    Console.WriteLine("4. Display Inventory");
                    Console.WriteLine("5. Exit");
                    int choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            addItem();
                            break;
                        case 2:
                            updatePro();
                            break;
                        case 3:
                            UpdateStock();
                            break;
                        case 4:
                        manageStore.displayInv();
                            break;
                        case 5:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Galat choice");
                            break;
                    }
                }while (true);
            }

            static void addItem()
            {
            store manager = new store();
            Console.Write("Id: ");
                int productId = int.Parse(Console.ReadLine());

                Console.Write("Name: ");
                string name = Console.ReadLine();

                Console.Write("Price: ");
                double price = Convert.ToDouble(Console.ReadLine());

                Console.Write("Quantity: ");
                int quantity = int.Parse(Console.ReadLine());

                Product newProduct = new Product(productId, name, price, quantity);
                manager.AddProduct(newProduct);
            }

            public static void updatePro()
            {
            store manager = new store();
                Console.Write("Id(Product which you want to update): ");
                int productId = int.Parse(Console.ReadLine());

                Console.Write("New Name: ");
                string name = Console.ReadLine();

                Console.Write("New Price: ");
                double price = Convert.ToDouble(Console.ReadLine());

                Console.Write("New Quantity: ");
                int quantity = int.Parse(Console.ReadLine());

                Product updatedProduct = new Product(productId, name, price, quantity);
                manager.UpdateProduct(productId, updatedProduct);
            }

            static void UpdateStock()
            {
            store manager = new store();
                Console.Write("Id(Product which you want to update): ");
                int productId = int.Parse(Console.ReadLine());

                Console.Write("Pieces Sold: ");
                int quantitySold = int.Parse(Console.ReadLine());

                manager.UpdateStock(productId, quantitySold);
            }
        }
    }