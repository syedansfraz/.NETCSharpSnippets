﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Super_Market_Management_Store
{
    public partial class DummyCart : Form
    {
        public DummyCart()
        {
            InitializeComponent();
        }

        private void DummyCart_Load(object sender, EventArgs e)
        {

        }
    }
}
