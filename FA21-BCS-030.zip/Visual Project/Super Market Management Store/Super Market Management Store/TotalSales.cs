﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Super_Market_Management_Store
{
    public partial class TotalSales : Form
    {
        public TotalSales()
        {
            InitializeComponent();
        }
        DatabaseConnection objConnect;
        string conString;
        DataSet ds;
        DataRow dRow;
        int MaxRows;
        int inc = 0;

        private void TotalSales_Load(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.salerecord;
            ds = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
            loadproduct();
        }
        public void loadproduct()
        {

            dataGridView1.Rows.Clear();
            inc = 0;
            while (inc < MaxRows)
            {
                dRow = ds.Tables[0].Rows[inc];
                dataGridView1.Rows.Add(dRow.ItemArray);
                inc++;
            }
        }
    }
}
