﻿using Super_Market_Management_Store.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Super_Market_Management_Store
{
    public partial class Cashier : Form
    {
        public Cashier()
        {
            InitializeComponent();
            //  lbldate.Text = DateTime.Now.ToString();
            //setdesvalue();
        }
        DatabaseConnection objConnect;
        string conString;
        DataSet ds;
        DataRow dRow;
        int MaxRows;
        int inc = 0;

        int priceofoneproduct = 0;
        double priceofwholecart = 0;

        private void Cashier_Load(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.Announcement;
            ds = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
            loadAnnouncement();
            timer2.Start();
        }
        public void loadAnnouncement()
        {

            dRow = ds.Tables[0].Rows[0];
            lblannouncement.Text = dRow["Announcement"].ToString();
        }

        private void lbldate_Click(object sender, EventArgs e)
        {

        }

        private void btndiscount_Click(object sender, EventArgs e)
        {

        }

        private void middlepanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            Search_Product search = new Search_Product();
            search.Show();


        }

        public void SetTextBoxValues(string description, string brand, string category, string price, string barcode)
        {

        }

        //private void btnnewproduct_Click(object sender, EventArgs e)
        //{
        // Search_Product newsearch = new Search_Product();
        // pricecalculation();
        // this.Hide();
        //newsearch.ShowDialog(this);
        // }
        public void pricecalculation()
        {
            try
            {

                //  priceofoneproduct = Convert.ToInt32(pricebox.Text) * Convert.ToInt32(quantitybox.Value);
                //  salestotallbl.Text = priceofoneproduct.ToString();
                // discountlbl.Text = discountbox.Value.ToString();
                double taxcalculate = Convert.ToDouble(priceofoneproduct) * 0.05;
                //  double discountedprice = (priceofoneproduct / 100) * Convert.ToDouble(discountbox.Value);
                //    taxlbl.Text = taxcalculate.ToString();
                //  priceofwholecart = priceofoneproduct + taxcalculate - discountedprice;
                //  maintotallbl.Text = priceofwholecart.ToString();
            }
            catch
            {
                MessageBox.Show("Please Fill this first");
            }
        }

        private void btndone_Click(object sender, EventArgs e)
        {
            pricecalculation();
        }



        private void endshoppingcheckbox_CheckedChanged(object sender, EventArgs e)
        {
            //  if (endshoppingcheckbox.Checked)
            {
                //     proceedtocart.Enabled = true;
            }
        }

        private void newproductcheckbox_CheckedChanged(object sender, EventArgs e)
        {
            // if (newproductcheckbox.Checked)
            {
                ///     proceedtocart.Enabled = true;
            }
        }

        private void proceedtocart_Click(object sender, EventArgs e)
        {
            pricecalculation();

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void proceedtocart_Click_1(object sender, EventArgs e)
        {

        }

        private void paneltitle_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Logout?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                login login = new login();
                login.ShowDialog();
            }
        }

        private void btnchangepass_Click(object sender, EventArgs e)
        {
            ChangePassword changePassword = new ChangePassword();
            changePassword.ShowDialog();
        }

        private void btnclearcart_Click(object sender, EventArgs e)
        {
            conString = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con2 = new SqlConnection(conString);
            con2.Open();
            string query2 = "DELETE From DummyCart;";
            SqlCommand cmd2 = new SqlCommand(query2, con2);
            cmd2.ExecuteNonQuery();
            MessageBox.Show("Action Performed");
            con2.Close();
        }

        private void btncart_Click(object sender, EventArgs e)
        {
            Cart cart = new Cart();
            cart.ShowDialog();
        }

        private void btnsales_Click(object sender, EventArgs e)
        {
            TotalSales totalSales = new TotalSales();
            totalSales.ShowDialog();
        }

        private void timelbl_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void datelbl_Click(object sender, EventArgs e)
        {
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timmelbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();

        }
    }

}
