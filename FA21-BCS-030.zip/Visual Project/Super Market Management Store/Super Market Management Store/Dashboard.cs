﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Super_Market_Management_Store
{
    public partial class Dashboard : Form
    {
        private string[] quotes = {
    "The only way to do great work is to love what you do. - Steve Jobs",
    "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill",
    "Your time is limited, don't waste it living someone else's life. - Steve Jobs",
    "Believe you can and you're halfway there. - Theodore Roosevelt",
    "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
    "Strive not to be a success, but rather to be of value. - Albert Einstein",
    "I have not failed. I've just found 10,000 ways that won't work. - Thomas A. Edison",
    "It is during our darkest moments that we must focus to see the light. - Aristotle",
    "The only limit to our realization of tomorrow will be our doubts of today. - Franklin D. Roosevelt",
    "Do not wait to strike till the iron is hot, but make it hot by striking. - William Butler Yeats",
    "In the end, we will remember not the words of our enemies, but the silence of our friends. - Martin Luther King Jr.",
    "The best way to predict the future is to create it. - Peter Drucker",
    "The only person you are destined to become is the person you decide to be. - Ralph Waldo Emerson",
    "Success usually comes to those who are too busy to be looking for it. - Henry David Thoreau",
    "The only impossible journey is the one you never begin. - Tony Robbins"
};

        private Random random = new Random();
        public Dashboard()
        {
            InitializeComponent();


            int hour = DateTime.Now.Hour;

            if (hour >= 10 && hour < 17)
            {
                //Open 10:00am through 4:59pm
                timinglbl.Text = "Store is Open";
            }
            else
            {
                //Closed 5:00pm through 9:59am
                timinglbl.Text = "Store is Closed";
            }
            if (hour >= 5 && hour < 12)
            {
                greetinglbl.Text = "Good Morning Sir!";
            }
            else if (hour >= 12 && hour < 15)
            {
                greetinglbl.Text = "Good Noon Sir!";
            }
            else if (hour >= 15 && hour < 18)
            {
                greetinglbl.Text = "Good Afternoon Sir!";
            }
            else
            {
                greetinglbl.Text = "Good Night Sir!";
            }
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            DisplayRandomQuote();
            string conStr = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string query = "SELECT SUM(Quantity) FROM Nameofproduct;";
            SqlCommand cmd = new SqlCommand(query, con);
            object result = cmd.ExecuteScalar();

            // Check if the result is not null before converting to a string
            if (result != null)
            {
                string sumTotal = result.ToString();

                // Assuming you have a label named 'label1' on your form
                totalproductlbl.Text = "" + sumTotal;
            }
            else
            {
                totalproductlbl.Text = "No data found"; // Or handle the case when there is no data
            }
            con.Close();

            string conStr2 = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con2 = new SqlConnection(conStr2);
            con2.Open();
            string query2 = "SELECT SUM(Total) FROM salesrecord;";
            SqlCommand cmd2 = new SqlCommand(query2, con2);
            object result2 = cmd2.ExecuteScalar();

            // Check if the result is not null before converting to a string
            if (result2 != null)
            {
                string sumTotal = result2.ToString();

                // Assuming you have a label named 'label1' on your form
                earninglbl.Text = "" + sumTotal;
            }
            else
            {
                earninglbl.Text = "No data found"; // Or handle the case when there is no data
            }
            con2.Close();



            string conStr23 = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con23 = new SqlConnection(conStr23);
            con23.Open();
            string query23 = "SELECT COUNT(Description) FROM Nameofproduct;";
            SqlCommand cmd23 = new SqlCommand(query23, con23);
            object result23 = cmd23.ExecuteScalar();

            // Check if the result is not null before converting to a string
            if (result23 != null)
            {
                string sumTotal = result23.ToString();

                // Assuming you have a label named 'label1' on your form
                productslbl.Text = "" + sumTotal;
            }
            else
            {
                productslbl.Text = "No data found"; // Or handle the case when there is no data
            }
            con2.Close();

            timer1.Start();

        }
        private void DisplayRandomQuote()
        {
            // Get a random index to select a quote from the array
            int randomIndex = random.Next(quotes.Length);

            // Display the selected quote on the label
            qoutelbl.Text = quotes[randomIndex];
        }
        private void newtaskbtn_Click(object sender, EventArgs e)
        {
            checkedListBox1.Items.Add(textBox1.Text);
            textBox1.Text = "";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timelbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();
        }

        private void POS1_Click(object sender, EventArgs e)
        {

        }

        private void timelbl_Click(object sender, EventArgs e)
        {

        }

        private void datelbl_Click(object sender, EventArgs e)
        {
        }

        private void timinglbl_Click(object sender, EventArgs e)
        {

        }

        private void greetinglbl_Click(object sender, EventArgs e)
        {

        }
    }
}
