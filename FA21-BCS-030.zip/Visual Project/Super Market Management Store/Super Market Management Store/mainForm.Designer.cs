﻿namespace Super_Market_Management_Store
{
    partial class mainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
            panelsidebar = new Panel();
            btnusersetting = new Button();
            btnsalehistroy = new Button();
            btnupcomingshipments = new Button();
            btnbrand = new Button();
            btnstockentry = new Button();
            btnproductlist = new Button();
            btncategory = new Button();
            btnannouncement = new Button();
            btnlogout = new Button();
            btnsupplier = new Button();
            btndashboard = new Button();
            panellogo = new Panel();
            pictureBox1 = new PictureBox();
            lblrole = new Label();
            paneltitle = new Panel();
            lbltitle = new Label();
            panelmain = new Panel();
            timer1 = new System.Windows.Forms.Timer(components);
            panelsidebar.SuspendLayout();
            panellogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            paneltitle.SuspendLayout();
            SuspendLayout();
            // 
            // panelsidebar
            // 
            panelsidebar.BackColor = Color.White;
            panelsidebar.Controls.Add(btnusersetting);
            panelsidebar.Controls.Add(btnsalehistroy);
            panelsidebar.Controls.Add(btnupcomingshipments);
            panelsidebar.Controls.Add(btnbrand);
            panelsidebar.Controls.Add(btnstockentry);
            panelsidebar.Controls.Add(btnproductlist);
            panelsidebar.Controls.Add(btncategory);
            panelsidebar.Controls.Add(btnannouncement);
            panelsidebar.Controls.Add(btnlogout);
            panelsidebar.Controls.Add(btnsupplier);
            panelsidebar.Controls.Add(btndashboard);
            panelsidebar.Controls.Add(panellogo);
            panelsidebar.Dock = DockStyle.Left;
            panelsidebar.Location = new Point(0, 0);
            panelsidebar.Name = "panelsidebar";
            panelsidebar.Size = new Size(257, 868);
            panelsidebar.TabIndex = 0;
            panelsidebar.Paint += panelsidebar_Paint;
            // 
            // btnusersetting
            // 
            btnusersetting.BackColor = SystemColors.ButtonHighlight;
            btnusersetting.FlatAppearance.BorderSize = 0;
            btnusersetting.FlatStyle = FlatStyle.Flat;
            btnusersetting.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            btnusersetting.ForeColor = Color.Salmon;
            btnusersetting.Image = (Image)resources.GetObject("btnusersetting.Image");
            btnusersetting.ImageAlign = ContentAlignment.MiddleLeft;
            btnusersetting.Location = new Point(5, 621);
            btnusersetting.Name = "btnusersetting";
            btnusersetting.Size = new Size(253, 47);
            btnusersetting.TabIndex = 5;
            btnusersetting.Text = "User";
            btnusersetting.UseVisualStyleBackColor = false;
            btnusersetting.Click += btnusersetting_Click;
            // 
            // btnsalehistroy
            // 
            btnsalehistroy.BackColor = SystemColors.ButtonHighlight;
            btnsalehistroy.FlatAppearance.BorderSize = 0;
            btnsalehistroy.FlatStyle = FlatStyle.Flat;
            btnsalehistroy.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            btnsalehistroy.ForeColor = Color.Salmon;
            btnsalehistroy.Image = (Image)resources.GetObject("btnsalehistroy.Image");
            btnsalehistroy.ImageAlign = ContentAlignment.MiddleLeft;
            btnsalehistroy.Location = new Point(-1, 568);
            btnsalehistroy.Name = "btnsalehistroy";
            btnsalehistroy.Padding = new Padding(10, 0, 0, 0);
            btnsalehistroy.Size = new Size(257, 47);
            btnsalehistroy.TabIndex = 6;
            btnsalehistroy.Text = "Sale History";
            btnsalehistroy.UseVisualStyleBackColor = false;
            btnsalehistroy.Click += btnsalehistroy_Click;
            // 
            // btnupcomingshipments
            // 
            btnupcomingshipments.BackColor = SystemColors.ButtonHighlight;
            btnupcomingshipments.FlatAppearance.BorderSize = 0;
            btnupcomingshipments.FlatStyle = FlatStyle.Flat;
            btnupcomingshipments.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            btnupcomingshipments.ForeColor = Color.Salmon;
            btnupcomingshipments.Image = (Image)resources.GetObject("btnupcomingshipments.Image");
            btnupcomingshipments.ImageAlign = ContentAlignment.MiddleLeft;
            btnupcomingshipments.Location = new Point(0, 460);
            btnupcomingshipments.Name = "btnupcomingshipments";
            btnupcomingshipments.Padding = new Padding(10, 0, 0, 0);
            btnupcomingshipments.Size = new Size(257, 50);
            btnupcomingshipments.TabIndex = 6;
            btnupcomingshipments.Text = "Pending Shipments";
            btnupcomingshipments.TextAlign = ContentAlignment.MiddleRight;
            btnupcomingshipments.UseVisualStyleBackColor = false;
            btnupcomingshipments.Click += btnupcomingshipments_Click;
            // 
            // btnbrand
            // 
            btnbrand.BackColor = SystemColors.ButtonHighlight;
            btnbrand.FlatAppearance.BorderSize = 0;
            btnbrand.FlatStyle = FlatStyle.Flat;
            btnbrand.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            btnbrand.ForeColor = Color.Salmon;
            btnbrand.Image = (Image)resources.GetObject("btnbrand.Image");
            btnbrand.ImageAlign = ContentAlignment.MiddleLeft;
            btnbrand.Location = new Point(0, 354);
            btnbrand.Name = "btnbrand";
            btnbrand.Padding = new Padding(10, 0, 0, 0);
            btnbrand.Size = new Size(257, 47);
            btnbrand.TabIndex = 6;
            btnbrand.Text = "Brand";
            btnbrand.UseVisualStyleBackColor = false;
            btnbrand.Click += btnbrand_Click;
            // 
            // btnstockentry
            // 
            btnstockentry.BackColor = SystemColors.ButtonHighlight;
            btnstockentry.FlatAppearance.BorderSize = 0;
            btnstockentry.FlatStyle = FlatStyle.Flat;
            btnstockentry.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            btnstockentry.ForeColor = Color.Salmon;
            btnstockentry.Image = (Image)resources.GetObject("btnstockentry.Image");
            btnstockentry.ImageAlign = ContentAlignment.MiddleLeft;
            btnstockentry.Location = new Point(-3, 407);
            btnstockentry.Name = "btnstockentry";
            btnstockentry.Padding = new Padding(10, 0, 0, 0);
            btnstockentry.Size = new Size(257, 47);
            btnstockentry.TabIndex = 5;
            btnstockentry.Text = "Stock Entry";
            btnstockentry.UseVisualStyleBackColor = false;
            btnstockentry.Click += btnstockentry_Click;
            // 
            // btnproductlist
            // 
            btnproductlist.BackColor = SystemColors.ButtonHighlight;
            btnproductlist.FlatAppearance.BorderSize = 0;
            btnproductlist.FlatStyle = FlatStyle.Flat;
            btnproductlist.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            btnproductlist.ForeColor = Color.Salmon;
            btnproductlist.Image = (Image)resources.GetObject("btnproductlist.Image");
            btnproductlist.ImageAlign = ContentAlignment.MiddleLeft;
            btnproductlist.Location = new Point(0, 245);
            btnproductlist.Name = "btnproductlist";
            btnproductlist.Padding = new Padding(10, 0, 0, 0);
            btnproductlist.Size = new Size(257, 47);
            btnproductlist.TabIndex = 3;
            btnproductlist.Text = "Product List";
            btnproductlist.UseVisualStyleBackColor = false;
            btnproductlist.Click += btnproductlist_Click;
            // 
            // btncategory
            // 
            btncategory.BackColor = SystemColors.ButtonHighlight;
            btncategory.FlatAppearance.BorderSize = 0;
            btncategory.FlatStyle = FlatStyle.Flat;
            btncategory.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            btncategory.ForeColor = Color.Salmon;
            btncategory.Image = (Image)resources.GetObject("btncategory.Image");
            btncategory.ImageAlign = ContentAlignment.MiddleLeft;
            btncategory.Location = new Point(0, 298);
            btncategory.Name = "btncategory";
            btncategory.Padding = new Padding(10, 0, 0, 0);
            btncategory.Size = new Size(257, 50);
            btncategory.TabIndex = 5;
            btncategory.Text = "Category";
            btncategory.UseVisualStyleBackColor = false;
            btncategory.Click += button4_Click;
            // 
            // btnannouncement
            // 
            btnannouncement.FlatAppearance.BorderSize = 0;
            btnannouncement.FlatStyle = FlatStyle.Flat;
            btnannouncement.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            btnannouncement.ForeColor = Color.Salmon;
            btnannouncement.Image = (Image)resources.GetObject("btnannouncement.Image");
            btnannouncement.ImageAlign = ContentAlignment.MiddleLeft;
            btnannouncement.Location = new Point(1, 674);
            btnannouncement.Name = "btnannouncement";
            btnannouncement.Padding = new Padding(10, 0, 0, 0);
            btnannouncement.Size = new Size(257, 42);
            btnannouncement.TabIndex = 9;
            btnannouncement.Text = "Announcement!";
            btnannouncement.UseVisualStyleBackColor = true;
            btnannouncement.Click += btnannouncement_Click;
            // 
            // btnlogout
            // 
            btnlogout.FlatAppearance.BorderSize = 0;
            btnlogout.FlatStyle = FlatStyle.Flat;
            btnlogout.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            btnlogout.ForeColor = Color.Salmon;
            btnlogout.Image = (Image)resources.GetObject("btnlogout.Image");
            btnlogout.ImageAlign = ContentAlignment.MiddleRight;
            btnlogout.Location = new Point(-1, 815);
            btnlogout.Name = "btnlogout";
            btnlogout.Padding = new Padding(10, 0, 0, 0);
            btnlogout.Size = new Size(257, 42);
            btnlogout.TabIndex = 8;
            btnlogout.Text = "Logout";
            btnlogout.TextAlign = ContentAlignment.MiddleLeft;
            btnlogout.UseVisualStyleBackColor = true;
            btnlogout.Click += btnlogout_Click;
            // 
            // btnsupplier
            // 
            btnsupplier.FlatAppearance.BorderSize = 0;
            btnsupplier.FlatStyle = FlatStyle.Flat;
            btnsupplier.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            btnsupplier.ForeColor = Color.Salmon;
            btnsupplier.Image = (Image)resources.GetObject("btnsupplier.Image");
            btnsupplier.ImageAlign = ContentAlignment.MiddleLeft;
            btnsupplier.Location = new Point(-3, 516);
            btnsupplier.Name = "btnsupplier";
            btnsupplier.Padding = new Padding(10, 0, 0, 0);
            btnsupplier.Size = new Size(257, 47);
            btnsupplier.TabIndex = 6;
            btnsupplier.Text = "Supplier";
            btnsupplier.UseVisualStyleBackColor = true;
            btnsupplier.Click += btnsupplier_Click;
            // 
            // btndashboard
            // 
            btndashboard.FlatAppearance.BorderSize = 0;
            btndashboard.FlatStyle = FlatStyle.Flat;
            btndashboard.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            btndashboard.ForeColor = Color.Salmon;
            btndashboard.Image = (Image)resources.GetObject("btndashboard.Image");
            btndashboard.ImageAlign = ContentAlignment.MiddleLeft;
            btndashboard.Location = new Point(1, 197);
            btndashboard.Name = "btndashboard";
            btndashboard.Padding = new Padding(10, 0, 0, 0);
            btndashboard.Size = new Size(253, 42);
            btndashboard.TabIndex = 2;
            btndashboard.Text = "Dashboard";
            btndashboard.UseVisualStyleBackColor = true;
            btndashboard.Click += btndashboard_Click;
            // 
            // panellogo
            // 
            panellogo.Controls.Add(pictureBox1);
            panellogo.Controls.Add(lblrole);
            panellogo.Location = new Point(0, 3);
            panellogo.Name = "panellogo";
            panellogo.Size = new Size(257, 187);
            panellogo.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(88, 38);
            pictureBox1.Margin = new Padding(4, 5, 4, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(78, 82);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // lblrole
            // 
            lblrole.AutoSize = true;
            lblrole.BackColor = Color.White;
            lblrole.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblrole.ForeColor = Color.Salmon;
            lblrole.Location = new Point(37, 125);
            lblrole.Margin = new Padding(4, 0, 4, 0);
            lblrole.Name = "lblrole";
            lblrole.Size = new Size(174, 32);
            lblrole.TabIndex = 1;
            lblrole.Text = "Administrator";
            // 
            // paneltitle
            // 
            paneltitle.Controls.Add(lbltitle);
            paneltitle.Dock = DockStyle.Top;
            paneltitle.Location = new Point(257, 0);
            paneltitle.Name = "paneltitle";
            paneltitle.Size = new Size(934, 60);
            paneltitle.TabIndex = 1;
            // 
            // lbltitle
            // 
            lbltitle.AutoSize = true;
            lbltitle.BackColor = Color.White;
            lbltitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            lbltitle.ForeColor = Color.Salmon;
            lbltitle.Location = new Point(411, 9);
            lbltitle.Name = "lbltitle";
            lbltitle.Size = new Size(161, 38);
            lbltitle.TabIndex = 0;
            lbltitle.Text = "Title Name";
            // 
            // panelmain
            // 
            panelmain.BackColor = Color.White;
            panelmain.Dock = DockStyle.Fill;
            panelmain.Location = new Point(257, 60);
            panelmain.Name = "panelmain";
            panelmain.Padding = new Padding(30, 0, 0, 0);
            panelmain.Size = new Size(934, 808);
            panelmain.TabIndex = 2;
            panelmain.Paint += panelmain_Paint;
            // 
            // timer1
            // 
            timer1.Interval = 10;
            timer1.Tick += timer1_Tick;
            // 
            // mainForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.White;
            ClientSize = new Size(1191, 868);
            Controls.Add(panelmain);
            Controls.Add(paneltitle);
            Controls.Add(panelsidebar);
            MinimumSize = new Size(1213, 924);
            Name = "mainForm";
            Text = "Super Market Manager";
            Load += main_Load;
            panelsidebar.ResumeLayout(false);
            panellogo.ResumeLayout(false);
            panellogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            paneltitle.ResumeLayout(false);
            paneltitle.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelsidebar;
        private Panel panellogo;
        private Panel paneltitle;
        private Panel panelmain;
        private Button btndashboard;
        private Button btncategory;
        private Button btnproductlist;
        private Button btnbrand;
        private Button btnupcomingshipments;
        private Button btnstockentry;
        private Button btnusersetting;
        private Button btnsalehistroy;
        private Button btnsupplier;
        private Button btnlogout;
        private Label lblrole;
        private PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
        private Label lbltitle;
        private Button btnannouncement;
    }
}