﻿namespace Super_Market_Management_Store
{
    partial class Announce_Here_
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label6 = new Label();
            announcetb = new TextBox();
            btnsavebrandname = new Button();
            SuspendLayout();
            // 
            // label6
            // 
            label6.BackColor = Color.Salmon;
            label6.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(35, 31);
            label6.Name = "label6";
            label6.Size = new Size(194, 45);
            label6.TabIndex = 25;
            label6.Text = "Announce Here:";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // announcetb
            // 
            announcetb.Location = new Point(235, 31);
            announcetb.Multiline = true;
            announcetb.Name = "announcetb";
            announcetb.Size = new Size(443, 46);
            announcetb.TabIndex = 1;
            announcetb.TextAlign = HorizontalAlignment.Center;
            announcetb.TextChanged += announcetb_TextChanged;
            // 
            // btnsavebrandname
            // 
            btnsavebrandname.BackColor = Color.Salmon;
            btnsavebrandname.Dock = DockStyle.Bottom;
            btnsavebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnsavebrandname.ForeColor = Color.White;
            btnsavebrandname.Location = new Point(0, 92);
            btnsavebrandname.Name = "btnsavebrandname";
            btnsavebrandname.Size = new Size(721, 52);
            btnsavebrandname.TabIndex = 26;
            btnsavebrandname.Text = "Announce!";
            btnsavebrandname.UseVisualStyleBackColor = false;
            btnsavebrandname.Click += btnsavebrandname_Click;
            // 
            // Announce_Here_
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(721, 144);
            Controls.Add(btnsavebrandname);
            Controls.Add(announcetb);
            Controls.Add(label6);
            Name = "Announce_Here_";
            Text = "Announce_Here_";
            Load += Announce_Here__Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label6;
        private TextBox announcetb;
        private Button btnsavebrandname;
    }
}