﻿namespace Super_Market_Management_Store
{
    partial class SupplierModule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addresstb = new TextBox();
            label1 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            suppliertb = new TextBox();
            label3 = new Label();
            label2 = new Label();
            btnclosebrandname = new Button();
            btnsavebrandname = new Button();
            contacttb = new TextBox();
            phonetb = new TextBox();
            emailtb = new TextBox();
            faxtb = new TextBox();
            SuspendLayout();
            // 
            // addresstb
            // 
            addresstb.Location = new Point(229, 79);
            addresstb.Name = "addresstb";
            addresstb.Size = new Size(464, 31);
            addresstb.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Salmon;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(64, 83);
            label1.Name = "label1";
            label1.Size = new Size(85, 25);
            label1.TabIndex = 38;
            label1.Text = "Address:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Salmon;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(395, 231);
            label6.Name = "label6";
            label6.Size = new Size(45, 25);
            label6.TabIndex = 37;
            label6.Text = "Fax:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Salmon;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(64, 129);
            label5.Name = "label5";
            label5.Size = new Size(145, 25);
            label5.TabIndex = 36;
            label5.Text = "Contact Person:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Salmon;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(64, 231);
            label4.Name = "label4";
            label4.Size = new Size(70, 25);
            label4.TabIndex = 35;
            label4.Text = "E-mail:";
            // 
            // suppliertb
            // 
            suppliertb.Location = new Point(229, 31);
            suppliertb.Name = "suppliertb";
            suppliertb.Size = new Size(464, 31);
            suppliertb.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Salmon;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(64, 37);
            label3.Name = "label3";
            label3.Size = new Size(88, 25);
            label3.TabIndex = 34;
            label3.Text = "Supplier:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Salmon;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(64, 175);
            label2.Name = "label2";
            label2.Size = new Size(71, 25);
            label2.TabIndex = 33;
            label2.Text = "Phone:";
            // 
            // btnclosebrandname
            // 
            btnclosebrandname.BackColor = Color.Salmon;
            btnclosebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnclosebrandname.ForeColor = Color.White;
            btnclosebrandname.Location = new Point(610, 309);
            btnclosebrandname.Name = "btnclosebrandname";
            btnclosebrandname.Size = new Size(134, 52);
            btnclosebrandname.TabIndex = 32;
            btnclosebrandname.Text = "Close";
            btnclosebrandname.UseVisualStyleBackColor = false;
            btnclosebrandname.Click += btnclosebrandname_Click;
            // 
            // btnsavebrandname
            // 
            btnsavebrandname.BackColor = Color.Salmon;
            btnsavebrandname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnsavebrandname.ForeColor = Color.White;
            btnsavebrandname.Location = new Point(417, 309);
            btnsavebrandname.Name = "btnsavebrandname";
            btnsavebrandname.Size = new Size(134, 52);
            btnsavebrandname.TabIndex = 31;
            btnsavebrandname.Text = "Save";
            btnsavebrandname.UseVisualStyleBackColor = false;
            btnsavebrandname.Click += btnsavebrandname_Click;
            // 
            // contacttb
            // 
            contacttb.Location = new Point(229, 127);
            contacttb.Name = "contacttb";
            contacttb.Size = new Size(464, 31);
            contacttb.TabIndex = 3;
            // 
            // phonetb
            // 
            phonetb.Location = new Point(229, 175);
            phonetb.Name = "phonetb";
            phonetb.Size = new Size(464, 31);
            phonetb.TabIndex = 4;
            // 
            // emailtb
            // 
            emailtb.Location = new Point(158, 228);
            emailtb.Name = "emailtb";
            emailtb.Size = new Size(208, 31);
            emailtb.TabIndex = 5;
            // 
            // faxtb
            // 
            faxtb.Location = new Point(469, 228);
            faxtb.Name = "faxtb";
            faxtb.Size = new Size(275, 31);
            faxtb.TabIndex = 6;
            // 
            // SupplierModule
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 393);
            Controls.Add(faxtb);
            Controls.Add(emailtb);
            Controls.Add(phonetb);
            Controls.Add(contacttb);
            Controls.Add(addresstb);
            Controls.Add(label1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(suppliertb);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnclosebrandname);
            Controls.Add(btnsavebrandname);
            Name = "SupplierModule";
            Text = "Supplier Module";
            Load += SupplierModule_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox addresstb;
        private Label label1;
        private Label label6;
        private Label label5;
        private Label label4;
        private TextBox suppliertb;
        private Label label3;
        private Label label2;
        private Button btnclosebrandname;
        private Button btnsavebrandname;
        private TextBox contacttb;
        private TextBox phonetb;
        private TextBox emailtb;
        private TextBox faxtb;
    }
}