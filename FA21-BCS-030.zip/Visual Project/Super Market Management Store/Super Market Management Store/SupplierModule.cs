﻿using Super_Market_Management_Store.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Super_Market_Management_Store
{
    public partial class SupplierModule : Form
    {
        public SupplierModule()
        {
            InitializeComponent();
        }
        DatabaseConnection objConnect;
        string conString;
        DataSet ds3;
        DataRow newRow;
        int MaxRows = 0;
        int inc = 0;
        private void btnsavebrandname_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to add this brand?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                newRow = ds3.Tables[0].NewRow();
                newRow["Supplier"] = suppliertb.Text;
                newRow["Address"] = addresstb.Text;
                newRow["ContactP"] = contacttb.Text;
                newRow["Phone"] = phonetb.Text;
                newRow["Email"] = emailtb.Text;
                newRow["fax"] = faxtb.Text;
                ds3.Tables[0].Rows.Add(newRow);
                try
                {

                    objConnect.UpdateDatabase(ds3);
                    MaxRows = MaxRows + 1;
                    inc = MaxRows - 1;
                    MessageBox.Show("Database updated");
                    this.Dispose();
                }
                catch (Exception err)
                {

                    MessageBox.Show(err.Message);
                }

            }
        }

        private void SupplierModule_Load(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.Supplier;
            ds3 = objConnect.GetConnection;
            MaxRows = ds3.Tables[0].Rows.Count;

        }

        private void btnclosebrandname_Click(object sender, EventArgs e)
        {
            this.Dispose(true);
        }
    }
}
