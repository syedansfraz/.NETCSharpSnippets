﻿using Super_Market_Management_Store.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Super_Market_Management_Store
{
    public partial class Search_Product : Form
    {

        public Search_Product()
        {
            InitializeComponent();
            // Cashier cashier = new Cashier();
            // cashier.setdesvalue();

        }
        DatabaseConnection objConnect;
        string conString;
        DataSet ds;
        DataRow dRow;
        int MaxRows;
        int inc = 0;
        SqlDataReader dr;


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Search_Product_Load(object sender, EventArgs e)
        {
            loadproduct();
        }
            /*objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.SQL3;
            ds = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
            loadproduct();
        }
        public void loadproduct()
        {

            dataGridView1.Rows.Clear();
            inc = 0;
            while (inc < MaxRows)
            {
                dRow = ds.Tables[0].Rows[inc];
                dataGridView1.Rows.Add(dRow.ItemArray);
                inc++;
            }
        }*/
            public void loadproduct() { 
            string constr12 = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con12 = new SqlConnection(constr12);
            con12.Open();
            SqlCommand cmd3 = new SqlCommand("DELETE FROM Nameofproduct WHERE Quantity <= 0", con12);
            cmd3.ExecuteNonQuery();
            SqlCommand cmd12 = new SqlCommand("SELECT * FROM Nameofproduct", con12);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd12);
            DataSet dataTable = new DataSet();
            adapter.Fill(dataTable);
            int maxrow = dataTable.Tables[0].Rows.Count;

            if (dataTable.Tables[0].Rows.Count != 0)
            {
                inc = 0;
                dataGridView1.Rows.Clear();
                while (inc < maxrow)
                {
                    dRow = dataTable.Tables[0].Rows[inc];
                    dataGridView1.Rows.Add(dRow.ItemArray);
                    inc++;
                }
            }
            else
            {


            }
            con12.Close();
        }
    int indexRow;
        private void searchbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();


        }

        public void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
    try {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count)
            {
                
                    // Get the selected row
                    DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                    // Assuming you have a table named "SelectedProducts" with columns similar to "Nameofproduct"
                    // You should modify this query based on your actual table structure
                    string insertQuery = "INSERT INTO DummyCart (Id,Description , Brand, Category,Price,Quantity,Barcode,Discount,Totalcart) VALUES (@Column0,@Column1, @Column2, @Column3,@Column4, @Column5, @Column6,@Column7,@Column4* @Column5)";

                    using (SqlConnection con = new SqlConnection(Properties.Settings.Default.EmployeesConnectionString))
                    using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                    {
                        // Assuming you have three columns in your "Nameofproduct" table
                        cmd.Parameters.AddWithValue("@Column0", selectedRow.Cells[0].Value.ToString());
                        cmd.Parameters.AddWithValue("@Column1", selectedRow.Cells[1].Value.ToString());
                        cmd.Parameters.AddWithValue("@Column2", selectedRow.Cells[2].Value.ToString());
                        cmd.Parameters.AddWithValue("@Column3", selectedRow.Cells[3].Value.ToString());
                        cmd.Parameters.AddWithValue("@Column4", Convert.ToDouble(selectedRow.Cells[4].Value.ToString()));
                        cmd.Parameters.AddWithValue("@Column5", 1);
                        cmd.Parameters.AddWithValue("@Column6", Convert.ToInt32(selectedRow.Cells[6].Value.ToString()));
                        cmd.Parameters.AddWithValue("@Column7", 0);
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Item Added to Cart");

                }



            


            else
            {
                MessageBox.Show("Please select a valid row.");
            }
        }
            catch{
                MessageBox.Show("Already Selected");
            }
        }
            
        
        
        //BindingSource binder = new BindingSource();
        private void button1_Click_1(object sender, EventArgs e)
        {
            string conStr = Properties.Settings.Default.EmployeesConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string query = "SELECT * FROM Nameofproduct WHERE Description = @username";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@username", searchtb.Text);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet dataTable = new DataSet();
            adapter.Fill(dataTable);


            if (dataTable.Tables[0].Rows.Count != 0)
            {
                dRow = dataTable.Tables[0].Rows[0];
                dataGridView1.Rows.Clear();
                dataGridView1.Rows.Add(dRow.ItemArray);
            }
            else
            {

                MessageBox.Show("No Product Found");
                loadproduct();
            }
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            loadproduct();
            searchtb.Text = "";
        }
    }
}
