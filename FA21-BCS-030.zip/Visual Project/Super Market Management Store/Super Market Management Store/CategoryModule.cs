﻿using Super_Market_Management_Store.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Super_Market_Management_Store
{
    public partial class CategoryModule : Form
    {
        public CategoryModule()
        {
            InitializeComponent();
        }
        DatabaseConnection objConnect;
        string conString;
        DataSet ds;
        DataRow dRow;
        int MaxRows;
        int inc = 0;

        private void CategoryModule_Load(object sender, EventArgs e)
        {
            objConnect = new DatabaseConnection();
            conString = Properties.Settings.Default.EmployeesConnectionString;
            objConnect.connection_string = conString;
            objConnect.Sql = Properties.Settings.Default.SQL2;
            ds = objConnect.GetConnection;
            MaxRows = ds.Tables[0].Rows.Count;
        }

        private void btnsavebrandname_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to add this brand?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                DataRow row = ds.Tables[0].NewRow();
                row[1] = brandnametxtbox.Text;
                ds.Tables[0].Rows.Add(row);
                try
                {

                    objConnect.UpdateDatabase(ds);
                    MaxRows = MaxRows + 1;
                    inc = MaxRows - 1;
                    this.Dispose();

                }
                catch (Exception err)
                {

                    MessageBox.Show(err.Message);

                }
            }
            

        }

        private void btnclosebrandname_Click(object sender, EventArgs e)
        {
            this.Dispose(true);
        }
    }
}
