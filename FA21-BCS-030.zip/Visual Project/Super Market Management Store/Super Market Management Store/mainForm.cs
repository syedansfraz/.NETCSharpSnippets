using Super_Market_Management_Store.Properties;

namespace Super_Market_Management_Store
{
    public partial class mainForm : Form
    {
        private bool isCollapsed;
        public mainForm()
        {
            InitializeComponent();
            openChildForm(new Dashboard());

        }
        private Form activeForm = null;
        public void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.Dock = DockStyle.Fill;
            lbltitle.Text = childForm.Text;
            panelmain.Controls.Add(childForm);
            panelmain.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void panelsidebar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            openChildForm(new Category());
        }

        private void panelproductmenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void btnproduct_Click(object sender, EventArgs e)
        {

        }

        private void main_Load(object sender, EventArgs e)
        {
        }

        private void btnbrand_Click(object sender, EventArgs e)
        {
            openChildForm(new AllBrands());
            //AllBrands brand = new AllBrands();
            // brand.ShowDialog();
        }

        private void btnproductlist_Click(object sender, EventArgs e)
        {
            openChildForm(new Products());
        }

        private void btnsupplier_Click(object sender, EventArgs e)
        {
            openChildForm(new Supplier());
        }

        private void btnusersetting_Click(object sender, EventArgs e)
        {
            openChildForm(new User());
        }

        private void btnupcomingshipments_Click(object sender, EventArgs e)
        {
            openChildForm(new UpcomingShipments());
        }

        private void btnstockentry_Click(object sender, EventArgs e)
        {
            openChildForm(new StockEntry());
        }

        private void btnannouncement_Click(object sender, EventArgs e)
        {
            Announce_Here_ announce = new Announce_Here_();
            announce.ShowDialog();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Logout?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                login login = new login();
                login.ShowDialog();
            }
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            openChildForm(new Dashboard());
        }

        private void btnsalehistroy_Click(object sender, EventArgs e)
        {
            TotalSales totalSales = new TotalSales();
            totalSales.ShowDialog();
        }

        private void panelmain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnproduct_Click_1(object sender, EventArgs e)
        {
        }
    }
}